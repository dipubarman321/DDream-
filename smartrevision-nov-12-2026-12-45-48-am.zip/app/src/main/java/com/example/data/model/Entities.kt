package com.example.data.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

enum class Priority {
    LOW, MEDIUM, HIGH
}

enum class TopicStatus {
    NOT_STARTED, IN_PROGRESS, COMPLETED
}

enum class RevisionMode {
    MODE_A_FIXED,        // Calculated from original study date (e.g. +4, +7, +10 days)
    MODE_B_SEQUENTIAL    // Calculated from actual completion of the previous revision
}

enum class MasteryLevel {
    LEARNING, REVIEWING, MASTERED
}

enum class PaymentStatus {
    PENDING, VERIFIED, REJECTED
}

@Entity(tableName = "user_profile")
data class UserProfile(
    @PrimaryKey val id: Long = 1L,
    val name: String = "Candidate Aspirant",
    val email: String = "candidate@bcsaspirant.bd",
    val targetExam: String = "47th BCS & Bangladesh Bank AD",
    val dailyTargetMinutes: Int = 360, // 6 hours
    val isPremium: Boolean = true,
    val currentStreakDays: Int = 14,
    val longestStreakDays: Int = 28,
    val avatarColorHex: String = "#4F46E5"
)

@Entity(tableName = "subjects")
data class Subject(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val colorHex: String,
    val iconName: String,
    val isDefault: Boolean = false,
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "chapters",
    foreignKeys = [
        ForeignKey(
            entity = Subject::class,
            parentColumns = ["id"],
            childColumns = ["subjectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("subjectId")]
)
data class Chapter(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subjectId: Long,
    val title: String,
    val orderIndex: Int = 0
)

@Entity(
    tableName = "topics",
    foreignKeys = [
        ForeignKey(
            entity = Chapter::class,
            parentColumns = ["id"],
            childColumns = ["chapterId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("chapterId"), Index("subjectId")]
)
data class Topic(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val chapterId: Long,
    val subjectId: Long,
    val title: String,
    val priority: Priority = Priority.MEDIUM,
    val status: TopicStatus = TopicStatus.NOT_STARTED,
    val description: String = "",
    val isDifficult: Boolean = false,
    val timeSpentMinutes: Int = 0,
    val initialStudyDateMillis: Long? = null,
    val topicNotes: String = ""
)

@Entity(tableName = "study_sessions")
data class StudySession(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subjectId: Long,
    val chapterId: Long? = null,
    val topicId: Long? = null,
    val subjectName: String,
    val chapterName: String = "",
    val topicName: String,
    val durationMinutes: Int,
    val startTimeMillis: Long,
    val endTimeMillis: Long,
    val notes: String = "",
    val sessionType: String = "Timer" // "Timer", "Pomodoro", "Manual"
)

@Entity(
    tableName = "revision_schedules",
    indices = [Index("topicId"), Index("subjectId"), Index("scheduledDateMillis")]
)
data class RevisionSchedule(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val topicId: Long,
    val subjectId: Long,
    val topicName: String,
    val subjectName: String,
    val chapterName: String = "",
    val intervalDays: Int, // e.g. 4, 7, 10
    val intervalIndex: Int, // 1st, 2nd, 3rd revision
    val originalStudyDateMillis: Long,
    val scheduledDateMillis: Long,
    val mode: RevisionMode = RevisionMode.MODE_A_FIXED,
    val isCompleted: Boolean = false,
    val completedDateMillis: Long? = null,
    val revisionNotes: String = "",
    val rating: Int = 0 // 1-5 self rating of recall
)

@Entity(tableName = "focus_sessions")
data class FocusSession(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val targetMinutes: Int,
    val completedMinutes: Int,
    val isCompleted: Boolean,
    val isInterrupted: Boolean,
    val interruptionReason: String = "",
    val subjectName: String = "",
    val topicName: String = "",
    val startTimeMillis: Long,
    val endTimeMillis: Long
)

@Entity(tableName = "blocked_apps")
data class BlockedApp(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val appName: String,
    val packageName: String,
    val category: String, // "Social Media", "Video & Entertainment", "Gaming", "Custom"
    val isBlocked: Boolean = true
)

@Entity(tableName = "study_notes")
data class StudyNote(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subjectId: Long,
    val topicId: Long? = null,
    val subjectName: String,
    val topicName: String = "",
    val title: String,
    val content: String,
    val tags: String = "", // Comma-separated tags
    val isFavorite: Boolean = false,
    val createdAtMillis: Long = System.currentTimeMillis(),
    val updatedAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "mcq_sessions")
data class McqSession(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subjectId: Long,
    val subjectName: String,
    val topicName: String,
    val totalAttempted: Int,
    val correctAnswers: Int,
    val incorrectAnswers: Int,
    val skippedQuestions: Int,
    val timeSpentMinutes: Int,
    val accuracyPercentage: Float,
    val dateMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "mock_exams")
data class MockExam(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val examName: String,
    val examDateMillis: Long,
    val totalMarks: Float,
    val marksObtained: Float,
    val correctAnswers: Int,
    val negativeMarks: Float,
    val timeTakenMinutes: Int,
    val subjectBreakdown: String = "", // JSON or summarized breakdown
    val comments: String = ""
)

@Entity(tableName = "vocabulary")
data class VocabularyWord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val word: String,
    val bengaliMeaning: String,
    val definition: String,
    val synonyms: String = "",
    val antonyms: String = "",
    val exampleSentence: String = "",
    val masteryLevel: MasteryLevel = MasteryLevel.LEARNING,
    val isFavorite: Boolean = false,
    val personalNotes: String = "",
    val nextReviewDateMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "exam_countdowns")
data class ExamCountdown(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val examName: String,
    val examDateMillis: Long,
    val targetStudyHours: Int,
    val completedHours: Float = 0f,
    val category: String = "BCS" // "BCS", "Bank", "Govt", "Admission", "Other"
)

@Entity(tableName = "app_notifications")
data class AppNotification(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val message: String,
    val type: String, // "REVISION_TODAY", "REVISION_OVERDUE", "DAILY_TARGET", "STREAK", "COUNTDOWN"
    val timestampMillis: Long = System.currentTimeMillis(),
    val isRead: Boolean = false,
    val actionRoute: String = ""
)

@Entity(tableName = "payment_transactions")
data class PaymentTransaction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val planName: String, // "Pro Monthly (৳199)", "Pro Yearly (৳1499)"
    val amount: Int,
    val paymentMethod: String, // "bKash", "Nagad", "Rocket"
    val transactionId: String,
    val senderNumber: String,
    val status: PaymentStatus = PaymentStatus.PENDING,
    val submittedAtMillis: Long = System.currentTimeMillis()
)
