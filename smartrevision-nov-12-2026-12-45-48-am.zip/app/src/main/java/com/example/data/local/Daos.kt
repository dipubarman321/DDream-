package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface UserProfileDao {
    @Query("SELECT * FROM user_profile WHERE id = 1 LIMIT 1")
    fun getUserProfile(): Flow<UserProfile?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(profile: UserProfile)

    @Update
    suspend fun update(profile: UserProfile)
}

@Dao
interface SubjectDao {
    @Query("SELECT * FROM subjects ORDER BY isDefault DESC, title ASC")
    fun getAllSubjects(): Flow<List<Subject>>

    @Query("SELECT * FROM subjects WHERE id = :id LIMIT 1")
    suspend fun getSubjectById(id: Long): Subject?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubject(subject: Subject): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubjects(subjects: List<Subject>)

    @Update
    suspend fun updateSubject(subject: Subject)

    @Delete
    suspend fun deleteSubject(subject: Subject)
}

@Dao
interface ChapterDao {
    @Query("SELECT * FROM chapters WHERE subjectId = :subjectId ORDER BY orderIndex ASC, title ASC")
    fun getChaptersBySubject(subjectId: Long): Flow<List<Chapter>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChapter(chapter: Chapter): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChapters(chapters: List<Chapter>)

    @Update
    suspend fun updateChapter(chapter: Chapter)

    @Delete
    suspend fun deleteChapter(chapter: Chapter)
}

@Dao
interface TopicDao {
    @Query("SELECT * FROM topics WHERE chapterId = :chapterId ORDER BY title ASC")
    fun getTopicsByChapter(chapterId: Long): Flow<List<Topic>>

    @Query("SELECT * FROM topics WHERE subjectId = :subjectId ORDER BY title ASC")
    fun getTopicsBySubject(subjectId: Long): Flow<List<Topic>>

    @Query("SELECT * FROM topics ORDER BY id DESC")
    fun getAllTopics(): Flow<List<Topic>>

    @Query("SELECT * FROM topics WHERE id = :id LIMIT 1")
    suspend fun getTopicById(id: Long): Topic?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTopic(topic: Topic): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTopics(topics: List<Topic>)

    @Update
    suspend fun updateTopic(topic: Topic)

    @Query("UPDATE topics SET status = :status, timeSpentMinutes = timeSpentMinutes + :additionalMinutes, initialStudyDateMillis = CASE WHEN initialStudyDateMillis IS NULL THEN :nowMillis ELSE initialStudyDateMillis END WHERE id = :topicId")
    suspend fun recordTopicStudy(topicId: Long, status: TopicStatus, additionalMinutes: Int, nowMillis: Long)

    @Delete
    suspend fun deleteTopic(topic: Topic)
}

@Dao
interface StudySessionDao {
    @Query("SELECT * FROM study_sessions ORDER BY startTimeMillis DESC")
    fun getAllSessions(): Flow<List<StudySession>>

    @Query("SELECT * FROM study_sessions WHERE startTimeMillis >= :startOfDayMillis ORDER BY startTimeMillis DESC")
    fun getTodaySessions(startOfDayMillis: Long): Flow<List<StudySession>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: StudySession): Long

    @Delete
    suspend fun deleteSession(session: StudySession)
}

@Dao
interface RevisionScheduleDao {
    @Query("SELECT * FROM revision_schedules ORDER BY scheduledDateMillis ASC")
    fun getAllRevisions(): Flow<List<RevisionSchedule>>

    @Query("SELECT * FROM revision_schedules WHERE scheduledDateMillis >= :startOfDayMillis AND scheduledDateMillis <= :endOfDayMillis AND isCompleted = 0 ORDER BY scheduledDateMillis ASC")
    fun getTodayRevisions(startOfDayMillis: Long, endOfDayMillis: Long): Flow<List<RevisionSchedule>>

    @Query("SELECT * FROM revision_schedules WHERE scheduledDateMillis > :endOfDayMillis AND isCompleted = 0 ORDER BY scheduledDateMillis ASC")
    fun getUpcomingRevisions(endOfDayMillis: Long): Flow<List<RevisionSchedule>>

    @Query("SELECT * FROM revision_schedules WHERE isCompleted = 1 ORDER BY completedDateMillis DESC")
    fun getCompletedRevisions(): Flow<List<RevisionSchedule>>

    @Query("SELECT * FROM revision_schedules WHERE scheduledDateMillis < :startOfDayMillis AND isCompleted = 0 ORDER BY scheduledDateMillis ASC")
    fun getOverdueRevisions(startOfDayMillis: Long): Flow<List<RevisionSchedule>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRevision(revision: RevisionSchedule): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRevisions(revisions: List<RevisionSchedule>)

    @Update
    suspend fun updateRevision(revision: RevisionSchedule)

    @Query("UPDATE revision_schedules SET isCompleted = 1, completedDateMillis = :completedMillis, revisionNotes = :notes, rating = :rating WHERE id = :id")
    suspend fun markCompleted(id: Long, completedMillis: Long, notes: String, rating: Int)

    @Query("UPDATE revision_schedules SET scheduledDateMillis = :newDateMillis WHERE id = :id")
    suspend fun reschedule(id: Long, newDateMillis: Long)

    @Delete
    suspend fun deleteRevision(revision: RevisionSchedule)
}

@Dao
interface FocusSessionDao {
    @Query("SELECT * FROM focus_sessions ORDER BY startTimeMillis DESC")
    fun getAllFocusSessions(): Flow<List<FocusSession>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFocusSession(session: FocusSession): Long
}

@Dao
interface BlockedAppDao {
    @Query("SELECT * FROM blocked_apps ORDER BY category ASC, appName ASC")
    fun getAllBlockedApps(): Flow<List<BlockedApp>>

    @Query("UPDATE blocked_apps SET isBlocked = :isBlocked WHERE id = :id")
    suspend fun toggleBlocked(id: Long, isBlocked: Boolean)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertApp(app: BlockedApp): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertApps(apps: List<BlockedApp>)

    @Delete
    suspend fun deleteApp(app: BlockedApp)
}

@Dao
interface StudyNoteDao {
    @Query("SELECT * FROM study_notes ORDER BY isFavorite DESC, updatedAtMillis DESC")
    fun getAllNotes(): Flow<List<StudyNote>>

    @Query("SELECT * FROM study_notes WHERE subjectId = :subjectId ORDER BY updatedAtMillis DESC")
    fun getNotesBySubject(subjectId: Long): Flow<List<StudyNote>>

    @Query("SELECT * FROM study_notes WHERE title LIKE '%' || :query || '%' OR content LIKE '%' || :query || '%' OR tags LIKE '%' || :query || '%'")
    fun searchNotes(query: String): Flow<List<StudyNote>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: StudyNote): Long

    @Update
    suspend fun updateNote(note: StudyNote)

    @Delete
    suspend fun deleteNote(note: StudyNote)
}

@Dao
interface McqSessionDao {
    @Query("SELECT * FROM mcq_sessions ORDER BY dateMillis DESC")
    fun getAllMcqSessions(): Flow<List<McqSession>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMcqSession(session: McqSession): Long

    @Delete
    suspend fun deleteMcqSession(session: McqSession)
}

@Dao
interface MockExamDao {
    @Query("SELECT * FROM mock_exams ORDER BY examDateMillis DESC")
    fun getAllMockExams(): Flow<List<MockExam>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMockExam(mock: MockExam): Long

    @Delete
    suspend fun deleteMockExam(mock: MockExam)
}

@Dao
interface VocabularyDao {
    @Query("SELECT * FROM vocabulary ORDER BY word ASC")
    fun getAllVocabulary(): Flow<List<VocabularyWord>>

    @Query("SELECT * FROM vocabulary WHERE isFavorite = 1 ORDER BY word ASC")
    fun getFavoriteVocabulary(): Flow<List<VocabularyWord>>

    @Query("UPDATE vocabulary SET masteryLevel = :level, nextReviewDateMillis = :nextReview WHERE id = :id")
    suspend fun updateMastery(id: Long, level: MasteryLevel, nextReview: Long)

    @Query("UPDATE vocabulary SET isFavorite = :isFav WHERE id = :id")
    suspend fun toggleFavorite(id: Long, isFav: Boolean)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWord(word: VocabularyWord): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWords(words: List<VocabularyWord>)

    @Delete
    suspend fun deleteWord(word: VocabularyWord)
}

@Dao
interface ExamCountdownDao {
    @Query("SELECT * FROM exam_countdowns ORDER BY examDateMillis ASC")
    fun getAllExams(): Flow<List<ExamCountdown>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExam(exam: ExamCountdown): Long

    @Update
    suspend fun updateExam(exam: ExamCountdown)

    @Delete
    suspend fun deleteExam(exam: ExamCountdown)
}

@Dao
interface AppNotificationDao {
    @Query("SELECT * FROM app_notifications ORDER BY timestampMillis DESC")
    fun getAllNotifications(): Flow<List<AppNotification>>

    @Query("SELECT COUNT(*) FROM app_notifications WHERE isRead = 0")
    fun getUnreadCount(): Flow<Int>

    @Query("UPDATE app_notifications SET isRead = 1 WHERE id = :id")
    suspend fun markAsRead(id: Long)

    @Query("UPDATE app_notifications SET isRead = 1")
    suspend fun markAllAsRead()

    @Query("DELETE FROM app_notifications")
    suspend fun clearAll()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: AppNotification): Long
}

@Dao
interface PaymentTransactionDao {
    @Query("SELECT * FROM payment_transactions ORDER BY submittedAtMillis DESC")
    fun getAllTransactions(): Flow<List<PaymentTransaction>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: PaymentTransaction): Long

    @Query("UPDATE payment_transactions SET status = :status WHERE id = :id")
    suspend fun updateStatus(id: Long, status: PaymentStatus)
}
