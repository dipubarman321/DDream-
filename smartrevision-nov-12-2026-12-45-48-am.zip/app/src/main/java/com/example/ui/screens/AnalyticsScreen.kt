package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.AppHeader
import com.example.ui.components.MetricStatCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel

@Composable
fun AnalyticsScreen(
    viewModel: MainViewModel,
    onMenuClick: () -> Unit
) {
    val studySessions by viewModel.studySessions.collectAsState()
    val allRevisions by viewModel.allRevisions.collectAsState()
    val focusSessions by viewModel.focusSessions.collectAsState()
    val mcqSessions by viewModel.mcqSessions.collectAsState()
    val mockExams by viewModel.mockExams.collectAsState()
    val unreadNotifications by viewModel.unreadNotificationsCount.collectAsState()

    val totalStudyMins = studySessions.sumOf { it.durationMinutes }
    val totalHours = totalStudyMins / 60f

    val completedRevCount = allRevisions.count { it.isCompleted }
    val pendingRevCount = allRevisions.count { !it.isCompleted }
    val revRate = if (allRevisions.isNotEmpty()) (completedRevCount * 100 / allRevisions.size) else 100

    val focusMins = focusSessions.sumOf { it.completedMinutes }
    val focusCompletedCount = focusSessions.count { it.isCompleted }
    val focusInterruptedCount = focusSessions.count { it.isInterrupted }

    // Subject Breakdown
    val subjectHours = studySessions.groupBy { it.subjectName }
        .mapValues { (_, sessions) -> sessions.sumOf { it.durationMinutes } / 60f }

    Scaffold(
        topBar = {
            AppHeader(
                title = "Performance Analytics",
                subtitle = "Study Duration, Revision Rate & Weak Topics",
                onMenuClick = onMenuClick,
                unreadNotifications = unreadNotifications,
                onNotificationsClick = { viewModel.navigateTo("notifications") }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 90.dp)
        ) {
            // Overview row
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    MetricStatCard(
                        title = "Study Duration",
                        value = "%.1fh".format(totalHours),
                        subtitle = "${studySessions.size} logged sessions",
                        icon = Icons.Default.Timer,
                        iconTint = BrandIndigo600,
                        modifier = Modifier.weight(1f)
                    )
                    MetricStatCard(
                        title = "Revision Success",
                        value = "$revRate%",
                        subtitle = "$completedRevCount done, $pendingRevCount due",
                        icon = Icons.Default.Psychology,
                        iconTint = SuccessEmerald,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Subject Distribution Chart Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(20.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = "Subject-Wise Study Allocation",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(14.dp))

                        if (subjectHours.isEmpty()) {
                            Text(
                                text = "Start studying to see your subject time allocation.",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                            )
                        } else {
                            val maxHours = (subjectHours.values.maxOrNull() ?: 1f).coerceAtLeast(1f)
                            subjectHours.forEach { (subject, hrs) ->
                                Column(modifier = Modifier.padding(vertical = 6.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = subject,
                                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold)
                                        )
                                        Text(
                                            text = "%.1f hrs".format(hrs),
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = BrandIndigo600,
                                                fontWeight = FontWeight.Bold
                                            )
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    LinearProgressIndicator(
                                        progress = { (hrs / maxHours).coerceIn(0f, 1f) },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(8.dp)
                                            .clip(RoundedCornerShape(4.dp)),
                                        color = BrandIndigo600,
                                        trackColor = Slate200
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Focus and Discipline Health Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(20.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = "Focus Shield & Distraction Health",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Total Focused Time", style = MaterialTheme.typography.labelSmall.copy(color = Slate400))
                                Text("%.1fh".format(focusMins / 60f), style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                            }
                            Column {
                                Text("Completed", style = MaterialTheme.typography.labelSmall.copy(color = Slate400))
                                Text("$focusCompletedCount Sessions", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = SuccessEmerald))
                            }
                            Column {
                                Text("Interrupted", style = MaterialTheme.typography.labelSmall.copy(color = Slate400))
                                Text("$focusInterruptedCount Sessions", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = AlertRose))
                            }
                        }
                    }
                }
            }

            // Weak Topics and Insights Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = WarningAmber.copy(alpha = 0.08f)),
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, WarningAmber.copy(alpha = 0.3f))
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lightbulb,
                            contentDescription = null,
                            tint = WarningAmber,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Intelligent Revision Recommendation",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = Slate900)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "You have higher study hours in Bangladesh Affairs and Mathematics. We recommend scheduling a 4-day revision for 'English Literature & Parts of Speech' to maintain balanced competitive cutoffs.",
                                style = MaterialTheme.typography.bodySmall.copy(color = Slate600)
                            )
                        }
                    }
                }
            }
        }
    }
}
