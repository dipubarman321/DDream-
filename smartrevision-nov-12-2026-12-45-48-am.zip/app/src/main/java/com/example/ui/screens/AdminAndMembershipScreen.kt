package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PaymentStatus
import com.example.ui.components.AppHeader
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminAndMembershipScreen(
    viewModel: MainViewModel,
    onMenuClick: () -> Unit
) {
    val profile by viewModel.userProfile.collectAsState()
    val transactions by viewModel.transactions.collectAsState()
    val unreadNotifications by viewModel.unreadNotificationsCount.collectAsState()
    val coroutineScope = rememberCoroutineScope()

    var showAdminPanel by remember { mutableStateOf(false) }
    var selectedPlan by remember { mutableStateOf("Pro Monthly (৳199)") }
    var selectedMethod by remember { mutableStateOf("bKash") }
    var transactionIdInput by remember { mutableStateOf("") }
    var senderNumberInput by remember { mutableStateOf("") }
    var paymentSuccessMessage by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            AppHeader(
                title = "Membership & Admin",
                subtitle = if (profile?.isPremium == true) "Active Pro Aspirant Tier" else "Free Starter Plan",
                onMenuClick = onMenuClick,
                unreadNotifications = unreadNotifications,
                onNotificationsClick = { viewModel.navigateTo("notifications") }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 90.dp)
        ) {
            // Plan Tier Badge Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = BrandNavy900),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Surface(
                                    color = WarningAmber,
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = "PRO CANDIDATE",
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = BrandNavy900,
                                            fontWeight = FontWeight.ExtraBold
                                        )
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = profile?.name ?: "Saif Ahmed",
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                )
                                Text(
                                    text = profile?.targetExam ?: "47th BCS & Bangladesh Bank AD",
                                    style = MaterialTheme.typography.bodySmall.copy(color = Slate400)
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .size(54.dp)
                                    .background(WarningAmber.copy(alpha = 0.2f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.WorkspacePremium,
                                    contentDescription = null,
                                    tint = WarningAmber,
                                    modifier = Modifier.size(32.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        HorizontalDivider(color = Slate700)
                        Spacer(modifier = Modifier.height(14.dp))

                        Text(
                            text = "Included Pro Features:",
                            style = MaterialTheme.typography.labelMedium.copy(color = Color.White, fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "✓ Unlimited 4-7-10 Spaced Revisions\n✓ Strict Focus Social Media & Entertainment App Lock\n✓ Full BCS & Bank Model Test Analytics\n✓ Offline SQLite Cloud-Ready Database\n✓ CSV Data & Study Reports Export",
                            style = MaterialTheme.typography.bodySmall.copy(color = Slate200, lineHeight = 20.sp)
                        )
                    }
                }
            }

            // Subscription Upgrade / Renewal Section
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(20.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = "Membership Plans & Payment",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        // Plan Selector
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FilterChip(
                                selected = selectedPlan == "Pro Monthly (৳199)",
                                onClick = { selectedPlan = "Pro Monthly (৳199)" },
                                label = { Text("Monthly (৳199)") },
                                modifier = Modifier.weight(1f)
                            )
                            FilterChip(
                                selected = selectedPlan == "Pro Yearly (৳1499)",
                                onClick = { selectedPlan = "Pro Yearly (৳1499)" },
                                label = { Text("Yearly (৳1499)") },
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Text("Payment Method (bKash / Nagad / Rocket):", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf("bKash", "Nagad", "Rocket").forEach { method ->
                                FilterChip(
                                    selected = selectedMethod == method,
                                    onClick = { selectedMethod = method },
                                    label = { Text(method) }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Surface(
                            color = Slate100,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "Merchant Number: 01700-123456 (Send Money/Payment)",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = Slate900)
                                )
                                Text(
                                    text = "Send the amount via $selectedMethod and enter your Transaction ID below.",
                                    style = MaterialTheme.typography.bodySmall.copy(color = Slate600)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = senderNumberInput,
                            onValueChange = { senderNumberInput = it },
                            label = { Text("Sender Mobile Number") },
                            placeholder = { Text("017XXXXXXXX") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = transactionIdInput,
                            onValueChange = { transactionIdInput = it },
                            label = { Text("Transaction ID (TrxID)") },
                            placeholder = { Text("e.g. BL99X8K72") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Button(
                            onClick = {
                                if (transactionIdInput.isNotBlank() && senderNumberInput.isNotBlank()) {
                                    val amount = if (selectedPlan.contains("1499")) 1499 else 199
                                    coroutineScope.launch {
                                        viewModel.repository.submitPayment(
                                            plan = selectedPlan,
                                            amount = amount,
                                            method = selectedMethod,
                                            txId = transactionIdInput,
                                            sender = senderNumberInput
                                        )
                                        paymentSuccessMessage = "Payment request submitted! Status: Pending verification."
                                        transactionIdInput = ""
                                        senderNumberInput = ""
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = SuccessEmerald)
                        ) {
                            Text("Submit Payment Request")
                        }

                        if (paymentSuccessMessage != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = paymentSuccessMessage!!,
                                style = MaterialTheme.typography.bodySmall.copy(color = SuccessEmerald, fontWeight = FontWeight.Bold)
                            )
                        }
                    }
                }
            }

            // Secure Admin Panel Toggle
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showAdminPanel = !showAdminPanel },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.AdminPanelSettings, contentDescription = null, tint = BrandIndigo600)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Administrator Dashboard",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "User counts, pending payments & approval tools",
                                    style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                )
                            }
                        }
                        Icon(
                            imageVector = if (showAdminPanel) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                            contentDescription = null
                        )
                    }
                }
            }

            // Admin Panel Body
            if (showAdminPanel) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(16.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "System Metrics",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("Registered Users", style = MaterialTheme.typography.labelSmall.copy(color = Slate400))
                                    Text("1,428 Aspirants", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                                }
                                Column {
                                    Text("Active Sessions", style = MaterialTheme.typography.labelSmall.copy(color = Slate400))
                                    Text("342 Studying Now", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = SuccessEmerald))
                                }
                                Column {
                                    Text("Pro Members", style = MaterialTheme.typography.labelSmall.copy(color = Slate400))
                                    Text("894", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = WarningAmber))
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "Payment Verification Queue (${transactions.size})",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            if (transactions.isEmpty()) {
                                Text(
                                    text = "No pending payment transactions in queue.",
                                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                )
                            } else {
                                transactions.forEach { tx ->
                                    val sdf = SimpleDateFormat("MMM d, hh:mm a", Locale.getDefault())
                                    Surface(
                                        color = Slate100,
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(10.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column {
                                                Text(
                                                    text = "${tx.paymentMethod} • ৳${tx.amount} • TrxID: ${tx.transactionId}",
                                                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                                                )
                                                Text(
                                                    text = "Sender: ${tx.senderNumber} • ${sdf.format(Date(tx.submittedAtMillis))}",
                                                    style = MaterialTheme.typography.labelSmall.copy(color = Slate600)
                                                )
                                            }
                                            if (tx.status == PaymentStatus.PENDING) {
                                                Button(
                                                    onClick = {
                                                        coroutineScope.launch {
                                                            viewModel.repository.updatePaymentStatus(tx.id, PaymentStatus.VERIFIED)
                                                        }
                                                    },
                                                    shape = RoundedCornerShape(8.dp),
                                                    colors = ButtonDefaults.buttonColors(containerColor = SuccessEmerald),
                                                    contentPadding = PaddingValues(horizontal = 8.dp),
                                                    modifier = Modifier.height(32.dp)
                                                ) {
                                                    Text("Approve ✓", fontSize = 11.sp)
                                                }
                                            } else {
                                                Text("Approved", color = SuccessEmerald, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
