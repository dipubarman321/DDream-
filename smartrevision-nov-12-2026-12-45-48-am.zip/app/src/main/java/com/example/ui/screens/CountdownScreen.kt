package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ExamCountdown
import com.example.ui.components.AppHeader
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CountdownScreen(
    viewModel: MainViewModel,
    onMenuClick: () -> Unit
) {
    val examCountdowns by viewModel.examCountdowns.collectAsState()
    val unreadNotifications by viewModel.unreadNotificationsCount.collectAsState()
    val coroutineScope = rememberCoroutineScope()

    var showAddDialog by remember { mutableStateOf(false) }
    var newExamName by remember { mutableStateOf("") }
    var newExamDays by remember { mutableStateOf("60") }
    var newTargetHours by remember { mutableStateOf("300") }
    var newCategory by remember { mutableStateOf("BCS") }

    Scaffold(
        topBar = {
            AppHeader(
                title = "Exam Countdowns",
                subtitle = "${examCountdowns.size} Target Examinations",
                onMenuClick = onMenuClick,
                unreadNotifications = unreadNotifications,
                onNotificationsClick = { viewModel.navigateTo("notifications") }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = AlertRose,
                contentColor = Color.White,
                modifier = Modifier.testTag("countdown_fab_add")
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Add Exam")
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 90.dp)
        ) {
            item {
                Text(
                    text = "Competitive Exam Timelines",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "Track remaining days, target hours, and progress towards your career milestones.",
                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                )
            }

            items(examCountdowns, key = { it.id }) { exam ->
                val daysLeft = ((exam.examDateMillis - System.currentTimeMillis()) / 86_400_000L).coerceAtLeast(0)
                val sdf = SimpleDateFormat("MMMM d, yyyy", Locale.getDefault())
                val examDateStr = sdf.format(Date(exam.examDateMillis))
                val progress = if (exam.targetStudyHours > 0) {
                    (exam.completedHours / exam.targetStudyHours).coerceIn(0f, 1f)
                } else 0f

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(20.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Surface(
                                    color = BrandIndigo100,
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = exam.category,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = BrandIndigo600,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = exam.examName,
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "Exam Date: $examDateStr",
                                    style = MaterialTheme.typography.bodySmall.copy(color = Slate400)
                                )
                            }
                            Surface(
                                color = if (daysLeft <= 30) AlertRose.copy(alpha = 0.15f) else WarningAmber.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Column(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        text = "$daysLeft",
                                        style = MaterialTheme.typography.titleLarge.copy(
                                            fontWeight = FontWeight.ExtraBold,
                                            color = if (daysLeft <= 30) AlertRose else WarningAmber
                                        )
                                    )
                                    Text(
                                        text = "Days Left",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = if (daysLeft <= 30) AlertRose else WarningAmber,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Target hours progress
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Preparation Progress: ${(progress * 100).toInt()}%",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "${exam.completedHours.toInt()}h / ${exam.targetStudyHours}h target",
                                style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = SuccessEmerald,
                            trackColor = Slate200
                        )
                    }
                }
            }
        }

        // Add Exam Dialog
        if (showAddDialog) {
            AlertDialog(
                onDismissRequest = { showAddDialog = false },
                title = { Text("Add Exam Countdown") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = newExamName,
                            onValueChange = { newExamName = it },
                            label = { Text("Exam Name") },
                            placeholder = { Text("e.g. 48th BCS Preliminary") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = newExamDays,
                            onValueChange = { newExamDays = it.filter { ch -> ch.isDigit() } },
                            label = { Text("Days Remaining from Today") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = newTargetHours,
                            onValueChange = { newTargetHours = it.filter { ch -> ch.isDigit() } },
                            label = { Text("Target Preparation Hours") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (newExamName.isNotBlank()) {
                                val days = newExamDays.toLongOrNull() ?: 60L
                                val target = newTargetHours.toIntOrNull() ?: 300
                                coroutineScope.launch {
                                    viewModel.repository.addExamCountdown(
                                        ExamCountdown(
                                            examName = newExamName,
                                            examDateMillis = System.currentTimeMillis() + (days * 86_400_000L),
                                            targetStudyHours = target,
                                            category = newCategory
                                        )
                                    )
                                    newExamName = ""
                                    showAddDialog = false
                                }
                            }
                        }
                    ) {
                        Text("Add Countdown")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showAddDialog = false }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}
