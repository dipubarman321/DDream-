package com.example

import com.example.data.model.Priority
import com.example.data.model.RevisionMode
import com.example.data.model.StudySession
import com.example.data.model.TopicStatus
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun spacedRepetition_ModeA_CalculatesFixedOffsetsCorrectly() {
        val originalStudyDate = 1700000000000L
        val dayMillis = 86_400_000L

        val intervals = listOf(4, 7, 10)
        val calculatedDates = intervals.map { days ->
            originalStudyDate + (days * dayMillis)
        }

        assertEquals(originalStudyDate + 4 * dayMillis, calculatedDates[0])
        assertEquals(originalStudyDate + 7 * dayMillis, calculatedDates[1])
        assertEquals(originalStudyDate + 10 * dayMillis, calculatedDates[2])
    }

    @Test
    fun mcqAccuracy_CalculationIsAccurate() {
        val totalAttempted = 50
        val correct = 42
        val accuracy = (correct.toFloat() / totalAttempted) * 100f

        assertEquals(84.0f, accuracy, 0.001f)
    }

    @Test
    fun mockExamNegativeMarking_DeductionCalculatesProperly() {
        val correctAnswers = 140
        val wrongAnswers = 20
        val marksPerQuestion = 1.0f
        val negativeDeductionPerWrong = 0.5f

        val netMarks = (correctAnswers * marksPerQuestion) - (wrongAnswers * negativeDeductionPerWrong)
        assertEquals(130.0f, netMarks, 0.001f)
    }

    @Test
    fun examCountdown_DaysRemainingCalculatesNonNegative() {
        val now = System.currentTimeMillis()
        val futureExamDate = now + (68 * 86_400_000L)
        val daysLeft = ((futureExamDate - now) / 86_400_000L).coerceAtLeast(0)

        assertEquals(68L, daysLeft)
    }

    @Test
    fun topicStatus_TransitionsStateEnum() {
        val initialStatus = TopicStatus.NOT_STARTED
        val inProgress = TopicStatus.IN_PROGRESS
        val completed = TopicStatus.COMPLETED

        assertNotEquals(initialStatus, inProgress)
        assertEquals(TopicStatus.COMPLETED, completed)
        assertEquals(Priority.HIGH, Priority.valueOf("HIGH"))
    }
}
