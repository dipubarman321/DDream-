package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel
import kotlinx.coroutines.launch

data class NavigationDrawerItemData(
    val route: String,
    val title: String,
    val icon: ImageVector,
    val badge: String? = null
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: MainViewModel) {
    val currentRoute by viewModel.currentScreen.collectAsState()
    val todayPendingRevisions by viewModel.todayPendingRevisions.collectAsState()
    val profile by viewModel.userProfile.collectAsState()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()

    // Handle system back navigation
    BackHandler(enabled = currentRoute != "dashboard" || drawerState.isOpen) {
        if (drawerState.isOpen) {
            coroutineScope.launch { drawerState.close() }
        } else if (currentRoute != "dashboard") {
            viewModel.navigateTo("dashboard")
        }
    }

    val drawerItems = listOf(
        NavigationDrawerItemData("dashboard", "Dashboard", Icons.Default.Dashboard),
        NavigationDrawerItemData("subjects", "Subjects & Syllabus", Icons.Default.MenuBook),
        NavigationDrawerItemData("study_timer", "Study Session Tracker", Icons.Default.PlayArrow),
        NavigationDrawerItemData(
            "revision",
            "Smart 4-7-10 Revisions",
            Icons.Default.Psychology,
            badge = if (todayPendingRevisions.isNotEmpty()) "${todayPendingRevisions.size}" else null
        ),
        NavigationDrawerItemData("focus", "Strict Focus & Blocker", Icons.Default.Lock),
        NavigationDrawerItemData("pomodoro", "Pomodoro Master", Icons.Default.Timer),
        NavigationDrawerItemData("calendar", "Study Calendar", Icons.Default.CalendarMonth),
        NavigationDrawerItemData("notes", "Study Notes", Icons.Default.NoteAlt),
        NavigationDrawerItemData("mcq", "MCQ Practice Tracker", Icons.Default.CheckCircle),
        NavigationDrawerItemData("mock_exams", "Mock Exam Tracker", Icons.Default.FactCheck),
        NavigationDrawerItemData("vocabulary", "English Vocabulary", Icons.Default.Translate),
        NavigationDrawerItemData("countdown", "Exam Countdowns", Icons.Default.Event),
        NavigationDrawerItemData("analytics", "Performance Analytics", Icons.Default.Insights),
        NavigationDrawerItemData("notifications", "Notification Centre", Icons.Default.Notifications),
        NavigationDrawerItemData("membership", "Membership & Admin", Icons.Default.WorkspacePremium),
        NavigationDrawerItemData("settings", "Settings & Export", Icons.Default.Settings)
    )

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                modifier = Modifier.width(310.dp),
                drawerContainerColor = MaterialTheme.colorScheme.surface
            ) {
                // Drawer Header
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(BrandNavy900)
                        .statusBarsPadding()
                        .padding(20.dp)
                ) {
                    Column {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .background(WarningAmber.copy(alpha = 0.2f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.School,
                                contentDescription = null,
                                tint = WarningAmber,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = profile?.name ?: "Saif Ahmed",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        )
                        Text(
                            text = profile?.targetExam ?: "47th BCS & Bangladesh Bank AD",
                            style = MaterialTheme.typography.bodySmall.copy(color = Slate400)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Surface(
                            color = SuccessEmerald.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "PRO CANDIDATE • 14-DAY STREAK",
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = SuccessEmerald,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp
                                )
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Scrollable Drawer Items
                androidx.compose.foundation.lazy.LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp)
                        .weight(1f)
                ) {
                    items(drawerItems.size) { index ->
                        val item = drawerItems[index]
                        val isSelected = currentRoute == item.route

                        NavigationDrawerItem(
                            label = {
                                Text(
                                    text = item.title,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                )
                            },
                            icon = {
                                Icon(
                                    imageVector = item.icon,
                                    contentDescription = item.title,
                                    tint = if (isSelected) BrandIndigo600 else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            },
                            badge = {
                                if (item.badge != null) {
                                    Surface(
                                        color = AlertRose,
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Text(
                                            text = item.badge,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = Color.White,
                                                fontWeight = FontWeight.Bold
                                            )
                                        )
                                    }
                                }
                            },
                            selected = isSelected,
                            onClick = {
                                viewModel.navigateTo(item.route)
                                coroutineScope.launch { drawerState.close() }
                            },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.padding(vertical = 2.dp)
                        )
                    }
                }

                Text(
                    text = "SmartRevision v2.0 • Asia/Dhaka BST",
                    style = MaterialTheme.typography.labelSmall.copy(color = Slate400),
                    modifier = Modifier
                        .padding(16.dp)
                        .navigationBarsPadding()
                )
            }
        }
    ) {
        Scaffold(
            bottomBar = {
                NavigationBar(
                    modifier = Modifier.navigationBarsPadding(),
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 8.dp
                ) {
                    val bottomItems = listOf(
                        Triple("dashboard", "Dashboard", Icons.Default.Dashboard),
                        Triple("subjects", "Subjects", Icons.Default.MenuBook),
                        Triple("study_timer", "Study", Icons.Default.PlayCircle),
                        Triple("revision", "Revision", Icons.Default.Psychology),
                        Triple("focus", "Focus", Icons.Default.Lock)
                    )

                    bottomItems.forEach { (route, label, icon) ->
                        val isSelected = currentRoute == route
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = { viewModel.navigateTo(route) },
                            icon = { Icon(imageVector = icon, contentDescription = label) },
                            label = { Text(label, fontSize = 11.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = BrandIndigo600,
                                selectedTextColor = BrandIndigo600,
                                indicatorColor = BrandIndigo100
                            ),
                            modifier = Modifier.testTag("nav_bottom_$route")
                        )
                    }
                }
            }
        ) { innerPadding ->
            Box(modifier = Modifier.fillMaxSize()) {
                when (currentRoute) {
                    "dashboard" -> DashboardScreen(viewModel = viewModel, onMenuClick = { coroutineScope.launch { drawerState.open() } })
                    "subjects" -> SubjectsScreen(viewModel = viewModel, onMenuClick = { coroutineScope.launch { drawerState.open() } })
                    "study_timer" -> StudyTrackerScreen(viewModel = viewModel, onMenuClick = { coroutineScope.launch { drawerState.open() } })
                    "revision" -> RevisionScreen(viewModel = viewModel, onMenuClick = { coroutineScope.launch { drawerState.open() } })
                    "focus" -> FocusModeScreen(viewModel = viewModel, onMenuClick = { coroutineScope.launch { drawerState.open() } })
                    "pomodoro" -> PomodoroScreen(viewModel = viewModel, onMenuClick = { coroutineScope.launch { drawerState.open() } })
                    "calendar" -> CalendarScreen(viewModel = viewModel, onMenuClick = { coroutineScope.launch { drawerState.open() } })
                    "notes" -> NotesScreen(viewModel = viewModel, onMenuClick = { coroutineScope.launch { drawerState.open() } })
                    "mcq" -> McqTrackerScreen(viewModel = viewModel, onMenuClick = { coroutineScope.launch { drawerState.open() } })
                    "mock_exams" -> MockExamScreen(viewModel = viewModel, onMenuClick = { coroutineScope.launch { drawerState.open() } })
                    "vocabulary" -> VocabularyScreen(viewModel = viewModel, onMenuClick = { coroutineScope.launch { drawerState.open() } })
                    "countdown" -> CountdownScreen(viewModel = viewModel, onMenuClick = { coroutineScope.launch { drawerState.open() } })
                    "analytics" -> AnalyticsScreen(viewModel = viewModel, onMenuClick = { coroutineScope.launch { drawerState.open() } })
                    "notifications" -> NotificationsScreen(viewModel = viewModel, onMenuClick = { coroutineScope.launch { drawerState.open() } })
                    "membership" -> AdminAndMembershipScreen(viewModel = viewModel, onMenuClick = { coroutineScope.launch { drawerState.open() } })
                    "settings" -> SettingsScreen(viewModel = viewModel, onMenuClick = { coroutineScope.launch { drawerState.open() } })
                    else -> DashboardScreen(viewModel = viewModel, onMenuClick = { coroutineScope.launch { drawerState.open() } })
                }
            }
        }
    }
}
