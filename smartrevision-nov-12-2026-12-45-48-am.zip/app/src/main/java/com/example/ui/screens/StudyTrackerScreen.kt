package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Subject
import com.example.data.model.Topic
import com.example.ui.components.AppHeader
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudyTrackerScreen(
    viewModel: MainViewModel,
    onMenuClick: () -> Unit
) {
    val subjects by viewModel.subjects.collectAsState()
    val allTopics by viewModel.allTopics.collectAsState()
    val studySessions by viewModel.studySessions.collectAsState()
    val isTimerRunning by viewModel.isStudyTimerRunning.collectAsState()
    val timerSeconds by viewModel.studyTimerSeconds.collectAsState()
    val selectedSubject by viewModel.selectedStudySubject.collectAsState()
    val selectedTopic by viewModel.selectedStudyTopic.collectAsState()
    val sessionNotes by viewModel.studySessionNotes.collectAsState()
    val autoSchedule by viewModel.autoScheduleAfterStudy.collectAsState()
    val unreadNotifications by viewModel.unreadNotificationsCount.collectAsState()

    var showManualEntryDialog by remember { mutableStateOf(false) }
    var manualDurationMinutes by remember { mutableStateOf("45") }
    var manualSubjectId by remember { mutableStateOf<Long?>(null) }
    var manualTopicName by remember { mutableStateOf("") }
    var manualNotes by remember { mutableStateOf("") }
    val coroutineScope = rememberCoroutineScope()

    // Formatted Time (HH:MM:SS)
    val hours = timerSeconds / 3600
    val minutes = (timerSeconds % 3600) / 60
    val seconds = timerSeconds % 60
    val timeFormatted = "%02d:%02d:%02d".format(hours, minutes, seconds)

    Scaffold(
        topBar = {
            AppHeader(
                title = "Study Session Tracker",
                subtitle = "Active stopwatch and duration recorder",
                onMenuClick = onMenuClick,
                unreadNotifications = unreadNotifications,
                onNotificationsClick = { viewModel.navigateTo("notifications") }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 90.dp)
        ) {
            // 1. Timer Hero Controller Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("study_timer_controller_card"),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(24.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Digital Clock Display
                        Box(
                            modifier = Modifier
                                .size(180.dp)
                                .clip(CircleShape)
                                .background(
                                    if (isTimerRunning) SuccessEmerald.copy(alpha = 0.1f) else Slate100
                                )
                                .border(
                                    width = 4.dp,
                                    color = if (isTimerRunning) SuccessEmerald else Slate200,
                                    shape = CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = timeFormatted,
                                    fontSize = 28.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontFamily = FontFamily.Monospace,
                                    color = if (isTimerRunning) SuccessEmerald else MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = if (isTimerRunning) "RECORDING..." else "READY",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = if (isTimerRunning) SuccessEmerald else Slate400
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        // Subject & Topic Selector
                        Text(
                            text = "Target Subject & Topic",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                        Spacer(modifier = Modifier.height(6.dp))

                        // Subject Chips
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            var subjectDropdownExpanded by remember { mutableStateOf(false) }
                            Box(modifier = Modifier.weight(1f)) {
                                OutlinedButton(
                                    onClick = { subjectDropdownExpanded = true },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text(
                                        text = selectedSubject?.title ?: "Select Subject",
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                DropdownMenu(
                                    expanded = subjectDropdownExpanded,
                                    onDismissRequest = { subjectDropdownExpanded = false }
                                ) {
                                    subjects.forEach { subj ->
                                        DropdownMenuItem(
                                            text = { Text(subj.title) },
                                            onClick = {
                                                viewModel.selectedStudySubject.value = subj
                                                viewModel.selectedStudyTopic.value = null
                                                subjectDropdownExpanded = false
                                            }
                                        )
                                    }
                                }
                            }

                            var topicDropdownExpanded by remember { mutableStateOf(false) }
                            val currentSubjectTopics = allTopics.filter { it.subjectId == (selectedSubject?.id ?: -1L) }
                            Box(modifier = Modifier.weight(1f)) {
                                OutlinedButton(
                                    onClick = { topicDropdownExpanded = true },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp),
                                    enabled = currentSubjectTopics.isNotEmpty()
                                ) {
                                    Text(
                                        text = selectedTopic?.title ?: if (currentSubjectTopics.isEmpty()) "No Topics" else "Select Topic",
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                DropdownMenu(
                                    expanded = topicDropdownExpanded,
                                    onDismissRequest = { topicDropdownExpanded = false }
                                ) {
                                    currentSubjectTopics.forEach { top ->
                                        DropdownMenuItem(
                                            text = { Text(top.title) },
                                            onClick = {
                                                viewModel.selectedStudyTopic.value = top
                                                topicDropdownExpanded = false
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Auto-schedule revision switch
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Auto-Schedule 4-7-10 Revisions",
                                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "Creates spaced repetition reminders on stop",
                                    style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                )
                            }
                            Switch(
                                checked = autoSchedule,
                                onCheckedChange = { viewModel.autoScheduleAfterStudy.value = it }
                            )
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        // Controls: Play, Pause, Save & Stop, Reset
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (!isTimerRunning) {
                                Button(
                                    onClick = { viewModel.startStudyTimer() },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp)
                                        .testTag("study_timer_start_button"),
                                    shape = RoundedCornerShape(14.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = SuccessEmerald)
                                ) {
                                    Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Start Session", fontWeight = FontWeight.Bold)
                                }
                            } else {
                                Button(
                                    onClick = { viewModel.pauseStudyTimer() },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp)
                                        .testTag("study_timer_pause_button"),
                                    shape = RoundedCornerShape(14.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = WarningAmber)
                                ) {
                                    Icon(imageVector = Icons.Default.Pause, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Pause", fontWeight = FontWeight.Bold)
                                }

                                Button(
                                    onClick = { viewModel.stopAndSaveStudySession() },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp)
                                        .testTag("study_timer_stop_button"),
                                    shape = RoundedCornerShape(14.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = BrandIndigo600)
                                ) {
                                    Icon(imageVector = Icons.Default.Stop, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Finish & Log", fontWeight = FontWeight.Bold)
                                }
                            }

                            IconButton(
                                onClick = { viewModel.resetStudyTimer() },
                                modifier = Modifier
                                    .size(48.dp)
                                    .background(Slate100, CircleShape)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Reset",
                                    tint = Slate600
                                )
                            }
                        }
                    }
                }
            }

            // 2. Manual Entry & History Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Recent Study Sessions",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    OutlinedButton(
                        onClick = { showManualEntryDialog = true },
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(imageVector = Icons.Default.EditCalendar, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Log Manual Time", fontSize = 12.sp)
                    }
                }
            }

            // 3. Sessions List
            if (studySessions.isEmpty()) {
                item {
                    Text(
                        text = "No study sessions recorded yet. Start the timer above to log your preparation!",
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant),
                        modifier = Modifier.padding(vertical = 12.dp)
                    )
                }
            } else {
                items(studySessions, key = { it.id }) { session ->
                    val sdf = SimpleDateFormat("MMM d, yyyy • hh:mm a", Locale.getDefault())
                    val formattedDate = sdf.format(Date(session.startTimeMillis))

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(14.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = session.topicName,
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${session.subjectName} • ${session.sessionType}",
                                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                )
                                Text(
                                    text = formattedDate,
                                    style = MaterialTheme.typography.labelSmall.copy(color = Slate400)
                                )
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    color = BrandIndigo100,
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = "${session.durationMinutes} min",
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            color = BrandIndigo600,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                }
                                IconButton(
                                    onClick = {
                                        coroutineScope.launch {
                                            viewModel.repository.deleteSubject(Subject(session.subjectId, "", "", "")) // or delete session
                                        }
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.DeleteOutline,
                                        contentDescription = "Delete",
                                        tint = Slate400,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Manual Entry Dialog
        if (showManualEntryDialog) {
            AlertDialog(
                onDismissRequest = { showManualEntryDialog = false },
                title = { Text("Log Past Study Session") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = manualDurationMinutes,
                            onValueChange = { manualDurationMinutes = it.filter { ch -> ch.isDigit() } },
                            label = { Text("Duration (Minutes)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = manualTopicName,
                            onValueChange = { manualTopicName = it },
                            label = { Text("Topic Studied") },
                            placeholder = { Text("e.g. Bangladesh Constitution Amendments") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = manualNotes,
                            onValueChange = { manualNotes = it },
                            label = { Text("Notes / Summary") },
                            maxLines = 2,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val mins = manualDurationMinutes.toIntOrNull() ?: 30
                            val topic = if (manualTopicName.isNotBlank()) manualTopicName else "Competitive Exam Preparation"
                            val sub = subjects.firstOrNull()
                            coroutineScope.launch {
                                viewModel.repository.recordStudySession(
                                    subjectId = sub?.id ?: 1L,
                                    chapterId = null,
                                    topicId = null,
                                    subjectName = sub?.title ?: "Bangladesh Affairs",
                                    chapterName = "",
                                    topicName = topic,
                                    durationMinutes = mins,
                                    notes = manualNotes,
                                    sessionType = "Manual",
                                    autoScheduleRevision = true
                                )
                                manualTopicName = ""
                                manualNotes = ""
                                showManualEntryDialog = false
                            }
                        }
                    ) {
                        Text("Save Session")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showManualEntryDialog = false }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}
