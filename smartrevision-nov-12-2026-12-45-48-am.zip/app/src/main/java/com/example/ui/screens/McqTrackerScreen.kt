package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.McqSession
import com.example.ui.components.AppHeader
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel
import kotlinx.coroutines.launch

data class McqQuestion(
    val question: String,
    val options: List<String>,
    val correctIndex: Int,
    val subject: String,
    val explanation: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun McqTrackerScreen(
    viewModel: MainViewModel,
    onMenuClick: () -> Unit
) {
    val mcqSessions by viewModel.mcqSessions.collectAsState()
    val unreadNotifications by viewModel.unreadNotificationsCount.collectAsState()
    val coroutineScope = rememberCoroutineScope()

    // 5 High-Yield BCS Questions for Live Practice
    val questions = remember {
        listOf(
            McqQuestion(
                question = "Who was the Commander-in-Chief of Bangladesh Armed Forces during the 1971 Liberation War?",
                options = listOf("Major Ziaur Rahman", "General M. A. G. Osmani", "Major Khaled Mosharraf", "Flight Lt. Matiur Rahman"),
                correctIndex = 1,
                subject = "Bangladesh Affairs",
                explanation = "General M. A. G. Osmani was appointed the Commander-in-Chief of the Mukti Bahini by the Mujibnagar Government."
            ),
            McqQuestion(
                question = "In the Constitution of Bangladesh, which Article guarantees 'Equality before law'?",
                options = listOf("Article 26", "Article 27", "Article 28", "Article 31"),
                correctIndex = 1,
                subject = "Bangladesh Constitution",
                explanation = "Article 27 states that all citizens are equal before law and are entitled to equal protection of law."
            ),
            McqQuestion(
                question = "If 15% of a number is 45, what is the value of the number?",
                options = listOf("250", "300", "350", "400"),
                correctIndex = 1,
                subject = "Mathematics",
                explanation = "0.15 * x = 45 => x = 45 / 0.15 = 300."
            ),
            McqQuestion(
                question = "Which of the following is a classic tragedy written by William Shakespeare?",
                options = listOf("The Alchemist", "Hamlet", "Paradise Lost", "Pride and Prejudice"),
                correctIndex = 1,
                subject = "English Literature",
                explanation = "'Hamlet' is one of Shakespeare's celebrated four great tragedies."
            ),
            McqQuestion(
                question = "In computer networking, which protocol resolves an IP address to a physical MAC address?",
                options = listOf("DHCP", "DNS", "ARP", "ICMP"),
                correctIndex = 2,
                subject = "Computer & ICT",
                explanation = "Address Resolution Protocol (ARP) translates an IP address into a local Ethernet MAC address."
            )
        )
    }

    var liveQuizActive by remember { mutableStateOf(false) }
    var currentQIndex by remember { mutableStateOf(0) }
    var selectedOption by remember { mutableStateOf<Int?>(null) }
    var userAnswers by remember { mutableStateOf(mutableMapOf<Int, Int>()) }
    var quizCompleted by remember { mutableStateOf(false) }

    // Summary calculations
    val totalAttempted = mcqSessions.sumOf { it.totalAttempted }
    val totalCorrect = mcqSessions.sumOf { it.correctAnswers }
    val overallAccuracy = if (totalAttempted > 0) ((totalCorrect.toFloat() / totalAttempted) * 100).toInt() else 0

    Scaffold(
        topBar = {
            AppHeader(
                title = "MCQ Practice Tracker",
                subtitle = "Exam Question Drill & Accuracy Analytics",
                onMenuClick = onMenuClick,
                unreadNotifications = unreadNotifications,
                onNotificationsClick = { viewModel.navigateTo("notifications") }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 90.dp)
        ) {
            // Live Quiz Runner Banner
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(20.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "BCS High-Yield Quick Drill",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "5 Selected Previous Year Questions",
                                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                )
                            }
                            Button(
                                onClick = {
                                    liveQuizActive = !liveQuizActive
                                    if (liveQuizActive) {
                                        currentQIndex = 0
                                        selectedOption = null
                                        userAnswers.clear()
                                        quizCompleted = false
                                    }
                                },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (liveQuizActive) Slate600 else BrandIndigo600
                                )
                            ) {
                                Text(if (liveQuizActive) "Close Drill" else "Start Drill")
                            }
                        }

                        // Active Quiz interface
                        AnimatedVisibility(visible = liveQuizActive) {
                            Column(modifier = Modifier.padding(top = 16.dp)) {
                                if (!quizCompleted) {
                                    val q = questions[currentQIndex]
                                    Text(
                                        text = "Question ${currentQIndex + 1} of ${questions.size} • ${q.subject}",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = BrandIndigo600,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = q.question,
                                        style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold)
                                    )

                                    Spacer(modifier = Modifier.height(14.dp))

                                    // Options
                                    q.options.forEachIndexed { optIndex, optionText ->
                                        val isChosen = selectedOption == optIndex
                                        Surface(
                                            color = if (isChosen) BrandIndigo100 else Slate100,
                                            shape = RoundedCornerShape(12.dp),
                                            border = androidx.compose.foundation.BorderStroke(
                                                width = if (isChosen) 2.dp else 1.dp,
                                                color = if (isChosen) BrandIndigo600 else Slate200
                                            ),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(vertical = 4.dp)
                                                .clickable { selectedOption = optIndex }
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(12.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(24.dp)
                                                        .background(
                                                            if (isChosen) BrandIndigo600 else Slate200,
                                                            CircleShape
                                                        ),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text(
                                                        text = ('A'.code + optIndex).toChar().toString(),
                                                        color = if (isChosen) Color.White else Slate600,
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }
                                                Spacer(modifier = Modifier.width(10.dp))
                                                Text(
                                                    text = optionText,
                                                    style = MaterialTheme.typography.bodyMedium
                                                )
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(14.dp))

                                    Button(
                                        onClick = {
                                            if (selectedOption != null) {
                                                userAnswers[currentQIndex] = selectedOption!!
                                                if (currentQIndex < questions.size - 1) {
                                                    currentQIndex += 1
                                                    selectedOption = null
                                                } else {
                                                    quizCompleted = true
                                                    // Calculate score and log session
                                                    var score = 0
                                                    questions.forEachIndexed { idx, qItem ->
                                                        if (userAnswers[idx] == qItem.correctIndex) score += 1
                                                    }
                                                    coroutineScope.launch {
                                                        viewModel.repository.addMcqSession(
                                                            McqSession(
                                                                subjectId = 1L,
                                                                subjectName = "BCS Drill",
                                                                topicName = "Multi-Subject Rapid Test",
                                                                totalAttempted = questions.size,
                                                                correctAnswers = score,
                                                                incorrectAnswers = questions.size - score,
                                                                skippedQuestions = 0,
                                                                timeSpentMinutes = 5,
                                                                accuracyPercentage = (score.toFloat() / questions.size) * 100
                                                            )
                                                        )
                                                    }
                                                }
                                            }
                                        },
                                        enabled = selectedOption != null,
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Text(if (currentQIndex < questions.size - 1) "Next Question →" else "Submit Drill & See Score")
                                    }
                                } else {
                                    // Results View
                                    var score = 0
                                    questions.forEachIndexed { idx, qItem ->
                                        if (userAnswers[idx] == qItem.correctIndex) score += 1
                                    }
                                    Column(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text(
                                            text = "Drill Completed! 🎉",
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "You scored $score / ${questions.size} (${(score * 100 / questions.size)}% Accuracy)",
                                            style = MaterialTheme.typography.bodyLarge.copy(
                                                color = SuccessEmerald,
                                                fontWeight = FontWeight.ExtraBold
                                            )
                                        )
                                        Spacer(modifier = Modifier.height(10.dp))
                                        Button(
                                            onClick = {
                                                liveQuizActive = false
                                                quizCompleted = false
                                            }
                                        ) {
                                            Text("Finish Drill")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Stats Cards
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Card(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text("Total Attempted", style = MaterialTheme.typography.labelSmall.copy(color = Slate400))
                            Text("$totalAttempted", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold))
                        }
                    }
                    Card(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text("Accuracy Rate", style = MaterialTheme.typography.labelSmall.copy(color = Slate400))
                            Text("$overallAccuracy%", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = SuccessEmerald))
                        }
                    }
                }
            }

            // Past MCQ Sessions History
            item {
                Text(
                    text = "MCQ Practice History",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                )
            }

            items(mcqSessions, key = { it.id }) { session ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(14.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = session.topicName,
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "${session.subjectName} • ${session.timeSpentMinutes} min drill",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                            )
                            Text(
                                text = "${session.correctAnswers} Correct, ${session.incorrectAnswers} Wrong",
                                style = MaterialTheme.typography.labelSmall.copy(color = Slate400)
                            )
                        }
                        Surface(
                            color = SuccessEmerald.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "${session.accuracyPercentage.toInt()}%",
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                style = MaterialTheme.typography.labelMedium.copy(
                                    color = SuccessEmerald,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}
