package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Brand Colors (Deep Navy & Intellect Indigo)
val BrandNavy900 = Color(0xFF0F172A)
val BrandNavy800 = Color(0xFF1E293B)
val BrandNavy700 = Color(0xFF334155)
val BrandIndigo600 = Color(0xFF4F46E5)
val BrandIndigo500 = Color(0xFF6366F1)
val BrandIndigo100 = Color(0xFFE0E7FF)

// Vibrant Semantic Accents
val SuccessEmerald = Color(0xFF10B981)
val SuccessEmeraldLight = Color(0xFFD1FAE5)
val WarningAmber = Color(0xFFF59E0B)
val WarningAmberLight = Color(0xFFFEF3C7)
val AlertRose = Color(0xFFEF4444)
val AlertRoseLight = Color(0xFFFEE2E2)
val InfoCyan = Color(0xFF06B6D4)
val PurpleAccent = Color(0xFF8B5CF6)

// Surface and Backgrounds
val Slate50 = Color(0xFFF8FAFC)
val Slate100 = Color(0xFFF1F5F9)
val Slate200 = Color(0xFFE2E8F0)
val Slate400 = Color(0xFF94A3B8)
val Slate600 = Color(0xFF475569)
val Slate700 = Color(0xFF334155)
val Slate900 = Color(0xFF0F172A)

// Card Gradients & Borders
val CardBorderLight = Color(0xFFE2E8F0)
val GoldStar = Color(0xFFFBBF24)
