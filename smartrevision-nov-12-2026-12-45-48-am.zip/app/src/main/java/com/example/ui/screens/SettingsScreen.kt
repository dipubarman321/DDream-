package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UserProfile
import com.example.ui.components.AppHeader
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    onMenuClick: () -> Unit
) {
    val profile by viewModel.userProfile.collectAsState()
    val studySessions by viewModel.studySessions.collectAsState()
    val unreadNotifications by viewModel.unreadNotificationsCount.collectAsState()
    val coroutineScope = rememberCoroutineScope()
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    var candidateName by remember(profile) { mutableStateOf(profile?.name ?: "Candidate Aspirant") }
    var candidateEmail by remember(profile) { mutableStateOf(profile?.email ?: "candidate@bcs.bd") }
    var targetExam by remember(profile) { mutableStateOf(profile?.targetExam ?: "47th BCS & Bangladesh Bank AD") }
    var dailyTargetHours by remember(profile) { mutableFloatStateOf((profile?.dailyTargetMinutes ?: 360) / 60f) }

    var soundEnabled by remember { mutableStateOf(true) }
    var vibrationEnabled by remember { mutableStateOf(true) }
    var exportPreviewDialog by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            AppHeader(
                title = "Settings & Export",
                subtitle = "Preferences, Timezone & Data Backup",
                onMenuClick = onMenuClick,
                unreadNotifications = unreadNotifications,
                onNotificationsClick = { viewModel.navigateTo("notifications") }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 90.dp)
        ) {
            // Profile & Target Exam
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(20.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = "Aspirant Profile",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = candidateName,
                            onValueChange = { candidateName = it },
                            label = { Text("Candidate Full Name") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = candidateEmail,
                            onValueChange = { candidateEmail = it },
                            label = { Text("Email Address") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = targetExam,
                            onValueChange = { targetExam = it },
                            label = { Text("Target Examination") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = {
                                coroutineScope.launch {
                                    viewModel.repository.updateProfile(
                                        profile?.copy(
                                            name = candidateName,
                                            email = candidateEmail,
                                            targetExam = targetExam,
                                            dailyTargetMinutes = (dailyTargetHours * 60).toInt()
                                        ) ?: UserProfile(
                                            name = candidateName,
                                            email = candidateEmail,
                                            targetExam = targetExam,
                                            dailyTargetMinutes = (dailyTargetHours * 60).toInt()
                                        )
                                    )
                                    Toast.makeText(context, "Profile updated successfully!", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Save Profile Changes")
                        }
                    }
                }
            }

            // Daily Target & Preferences
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(20.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = "Study Targets & Timezone",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "Daily Study Target: ${dailyTargetHours.toInt()} Hours (${(dailyTargetHours * 60).toInt()} Mins)",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                        )
                        Slider(
                            value = dailyTargetHours,
                            onValueChange = { dailyTargetHours = it },
                            valueRange = 2f..12f,
                            steps = 9
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Surface(
                            color = Slate100,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(imageVector = Icons.Default.Schedule, contentDescription = null, tint = BrandIndigo600)
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "Timezone: Asia/Dhaka (GMT+6)",
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Text(
                                        text = "All spaced repetition reminders are scheduled in Bangladesh Standard Time.",
                                        style = MaterialTheme.typography.labelSmall.copy(color = Slate600)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Timer Alert Sounds", style = MaterialTheme.typography.bodyMedium)
                            Switch(checked = soundEnabled, onCheckedChange = { soundEnabled = it })
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Haptic Vibration Alerts", style = MaterialTheme.typography.bodyMedium)
                            Switch(checked = vibrationEnabled, onCheckedChange = { vibrationEnabled = it })
                        }
                    }
                }
            }

            // Data Export & Backup
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(20.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = "Export & Data Portability",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "Export your study logs, revision milestones, and MCQ performance to standard CSV format.",
                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                        Spacer(modifier = Modifier.height(14.dp))

                        Button(
                            onClick = {
                                val csv = viewModel.repository.generateCsv(studySessions)
                                exportPreviewDialog = csv
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = BrandIndigo600)
                        ) {
                            Icon(imageVector = Icons.Default.FileDownload, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Export Study Sessions to CSV")
                        }
                    }
                }
            }
        }

        // Export Dialog Preview
        if (exportPreviewDialog != null) {
            AlertDialog(
                onDismissRequest = { exportPreviewDialog = null },
                title = { Text("CSV Export Preview") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Exported CSV content ready to copy or save:")
                        OutlinedTextField(
                            value = exportPreviewDialog!!,
                            onValueChange = {},
                            readOnly = true,
                            maxLines = 8,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            clipboardManager.setText(AnnotatedString(exportPreviewDialog!!))
                            Toast.makeText(context, "CSV copied to clipboard!", Toast.LENGTH_SHORT).show()
                            exportPreviewDialog = null
                        }
                    ) {
                        Text("Copy to Clipboard")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { exportPreviewDialog = null }) {
                        Text("Close")
                    }
                }
            )
        }
    }
}
