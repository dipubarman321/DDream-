package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.AppHeader
import com.example.ui.components.MetricStatCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel

@Composable
fun DashboardScreen(
    viewModel: MainViewModel,
    onMenuClick: () -> Unit
) {
    val profile by viewModel.userProfile.collectAsState()
    val todayPendingRevisions by viewModel.todayPendingRevisions.collectAsState()
    val upcomingRevisions by viewModel.upcomingRevisions.collectAsState()
    val completedRevisions by viewModel.completedRevisions.collectAsState()
    val overdueRevisions by viewModel.overdueRevisions.collectAsState()
    val studySessions by viewModel.studySessions.collectAsState()
    val focusSessions by viewModel.focusSessions.collectAsState()
    val examCountdowns by viewModel.examCountdowns.collectAsState()
    val unreadNotifications by viewModel.unreadNotificationsCount.collectAsState()

    // Aggregate statistics
    val totalStudyMinutes = studySessions.sumOf { it.durationMinutes }
    val totalStudyHours = totalStudyMinutes / 60f

    // Calculate today's study minutes
    val startOfToday = java.util.Calendar.getInstance().apply {
        set(java.util.Calendar.HOUR_OF_DAY, 0)
        set(java.util.Calendar.MINUTE, 0)
        set(java.util.Calendar.SECOND, 0)
        set(java.util.Calendar.MILLISECOND, 0)
    }.timeInMillis
    val todaySessions = studySessions.filter { it.startTimeMillis >= startOfToday }
    val todayStudyMinutes = todaySessions.sumOf { it.durationMinutes }
    val todayStudyHours = todayStudyMinutes / 60f

    val dailyTargetMinutes = profile?.dailyTargetMinutes ?: 360
    val dailyTargetHours = dailyTargetMinutes / 60f
    val dailyProgressPercent = (todayStudyMinutes.toFloat() / dailyTargetMinutes).coerceIn(0f, 1f)

    // Revision statistics
    val totalRevisionsCount = todayPendingRevisions.size + upcomingRevisions.size + completedRevisions.size + overdueRevisions.size
    val revisionCompletionRate = if (totalRevisionsCount > 0) {
        ((completedRevisions.size.toFloat() / totalRevisionsCount) * 100).toInt()
    } else 100

    // Focus statistics
    val totalFocusMinutes = focusSessions.sumOf { it.completedMinutes }
    val totalFocusHours = totalFocusMinutes / 60f
    val completedFocusSessions = focusSessions.count { it.isCompleted }
    val interruptedFocusSessions = focusSessions.count { it.isInterrupted }
    val focusScore = if (completedFocusSessions + interruptedFocusSessions > 0) {
        ((completedFocusSessions.toFloat() / (completedFocusSessions + interruptedFocusSessions)) * 100).toInt()
    } else 95

    Scaffold(
        topBar = {
            AppHeader(
                title = "SmartRevision",
                subtitle = profile?.targetExam ?: "47th BCS & Bangladesh Bank AD",
                onMenuClick = onMenuClick,
                unreadNotifications = unreadNotifications,
                onNotificationsClick = { viewModel.navigateTo("notifications") },
                streakDays = profile?.currentStreakDays ?: 14
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 80.dp)
        ) {
            // 1. Hero Daily Study Progress Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("daily_progress_hero_card"),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(20.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Daily Study Target",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "Timezone: Asia/Dhaka (UTC+6)",
                                    style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                )
                            }
                            Surface(
                                color = BrandIndigo100,
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text(
                                    text = "${(dailyProgressPercent * 100).toInt()}% Done",
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        color = BrandIndigo600,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Progress Bar
                        LinearProgressIndicator(
                            progress = { dailyProgressPercent },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(10.dp)
                                .clip(RoundedCornerShape(5.dp)),
                            color = SuccessEmerald,
                            trackColor = Slate200
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = "Completed",
                                    style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                )
                                Text(
                                    text = "%.1fh (%dm)".format(todayStudyHours, todayStudyMinutes),
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = SuccessEmerald)
                                )
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "Target",
                                    style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                )
                                Text(
                                    text = "%.1fh".format(dailyTargetHours),
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "Remaining",
                                    style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                )
                                val remainingMinutes = (dailyTargetMinutes - todayStudyMinutes).coerceAtLeast(0)
                                Text(
                                    text = "%.1fh".format(remainingMinutes / 60f),
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = AlertRose)
                                )
                            }
                        }
                    }
                }
            }

            // 2. Exam Countdown Banner
            val nearestExam = examCountdowns.firstOrNull()
            if (nearestExam != null) {
                val daysLeft = ((nearestExam.examDateMillis - System.currentTimeMillis()) / (86_400_000L)).coerceAtLeast(0)
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.navigateTo("countdown") }
                            .testTag("dashboard_countdown_banner"),
                        colors = CardDefaults.cardColors(containerColor = BrandNavy900),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .background(WarningAmber.copy(alpha = 0.2f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Event,
                                    contentDescription = null,
                                    tint = WarningAmber,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = nearestExam.examName,
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold
                                    ),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "Target ${nearestExam.targetStudyHours}h • Completed ${nearestExam.completedHours.toInt()}h",
                                    style = MaterialTheme.typography.bodySmall.copy(color = Slate400)
                                )
                            }
                            Surface(
                                color = WarningAmber,
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text(
                                    text = "${daysLeft} Days",
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        color = BrandNavy900,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                )
                            }
                        }
                    }
                }
            }

            // 3. Quick Action Launchpad
            item {
                Text(
                    text = "Quick Actions",
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                )
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        QuickActionPill(
                            title = "Study Timer",
                            icon = Icons.Default.PlayArrow,
                            color = BrandIndigo600,
                            onClick = { viewModel.navigateTo("study_timer") }
                        )
                    }
                    item {
                        QuickActionPill(
                            title = "Strict Focus",
                            icon = Icons.Default.Lock,
                            color = AlertRose,
                            onClick = { viewModel.navigateTo("focus") }
                        )
                    }
                    item {
                        QuickActionPill(
                            title = "Pomodoro",
                            icon = Icons.Default.Timer,
                            color = WarningAmber,
                            onClick = { viewModel.navigateTo("pomodoro") }
                        )
                    }
                    item {
                        QuickActionPill(
                            title = "Revisions",
                            icon = Icons.Default.Psychology,
                            color = SuccessEmerald,
                            onClick = { viewModel.navigateTo("revision") }
                        )
                    }
                    item {
                        QuickActionPill(
                            title = "MCQ Practice",
                            icon = Icons.Default.CheckCircle,
                            color = InfoCyan,
                            onClick = { viewModel.navigateTo("mcq") }
                        )
                    }
                    item {
                        QuickActionPill(
                            title = "Vocabulary",
                            icon = Icons.Default.Translate,
                            color = PurpleAccent,
                            onClick = { viewModel.navigateTo("vocabulary") }
                        )
                    }
                }
            }

            // 4. Study & Revision Metrics Grid
            item {
                Text(
                    text = "Core Performance",
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    MetricStatCard(
                        title = "Total Study",
                        value = "%.1fh".format(totalStudyHours),
                        subtitle = "${studySessions.size} total sessions",
                        icon = Icons.Default.MenuBook,
                        iconTint = BrandIndigo600,
                        modifier = Modifier.weight(1f)
                    )
                    MetricStatCard(
                        title = "Pending Revisions",
                        value = "${todayPendingRevisions.size}",
                        subtitle = "${overdueRevisions.size} overdue",
                        icon = Icons.Default.PendingActions,
                        iconTint = if (overdueRevisions.isNotEmpty()) AlertRose else SuccessEmerald,
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    MetricStatCard(
                        title = "Focus Time",
                        value = "%.1fh".format(totalFocusHours),
                        subtitle = "Score: $focusScore%",
                        icon = Icons.Default.TrackChanges,
                        iconTint = PurpleAccent,
                        modifier = Modifier.weight(1f)
                    )
                    MetricStatCard(
                        title = "Revision Rate",
                        value = "$revisionCompletionRate%",
                        subtitle = "${completedRevisions.size} completed",
                        icon = Icons.Default.Autorenew,
                        iconTint = SuccessEmerald,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // 5. Today's Pending Revisions Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.navigateTo("revision") }
                        .testTag("dashboard_revisions_card"),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .background(SuccessEmerald.copy(alpha = 0.15f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.CalendarToday,
                                        contentDescription = null,
                                        tint = SuccessEmerald,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "Smart 4-7-10 Revisions",
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Text(
                                        text = "${todayPendingRevisions.size} due today • ${overdueRevisions.size} overdue",
                                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    )
                                }
                            }
                            Text(
                                text = "View All →",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    color = BrandIndigo600,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }

                        if (todayPendingRevisions.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(12.dp))
                            todayPendingRevisions.take(2).forEach { rev ->
                                Surface(
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = rev.topicName,
                                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                text = "${rev.subjectName} • ${rev.intervalDays}-day interval",
                                                style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            )
                                        }
                                        Button(
                                            onClick = { viewModel.markRevisionComplete(rev, "Completed from dashboard", 5) },
                                            modifier = Modifier.height(34.dp),
                                            shape = RoundedCornerShape(8.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = SuccessEmerald),
                                            contentPadding = PaddingValues(horizontal = 10.dp)
                                        ) {
                                            Text("Done", fontSize = 12.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun QuickActionPill(
    title: String,
    icon: ImageVector,
    color: Color,
    onClick: () -> Unit
) {
    Surface(
        color = color.copy(alpha = 0.12f),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
            .clickable { onClick() }
            .testTag("quick_action_$title")
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = color
                )
            )
        }
    }
}
