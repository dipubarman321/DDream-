package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MockExam
import com.example.ui.components.AppHeader
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MockExamScreen(
    viewModel: MainViewModel,
    onMenuClick: () -> Unit
) {
    val mockExams by viewModel.mockExams.collectAsState()
    val unreadNotifications by viewModel.unreadNotificationsCount.collectAsState()
    val coroutineScope = rememberCoroutineScope()

    var showAddExamDialog by remember { mutableStateOf(false) }
    var examName by remember { mutableStateOf("") }
    var totalMarksStr by remember { mutableStateOf("200") }
    var marksObtainedStr by remember { mutableStateOf("135.5") }
    var correctCountStr by remember { mutableStateOf("150") }
    var negativeMarksStr by remember { mutableStateOf("14.5") }
    var timeTakenStr by remember { mutableStateOf("120") }
    var commentsStr by remember { mutableStateOf("") }

    val highestScore = mockExams.maxOfOrNull { it.marksObtained } ?: 0f
    val averageScore = if (mockExams.isNotEmpty()) mockExams.map { it.marksObtained }.average().toFloat() else 0f

    Scaffold(
        topBar = {
            AppHeader(
                title = "Mock Examination Tracker",
                subtitle = "BCS & Bank Model Test Scoreboard",
                onMenuClick = onMenuClick,
                unreadNotifications = unreadNotifications,
                onNotificationsClick = { viewModel.navigateTo("notifications") }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddExamDialog = true },
                containerColor = BrandIndigo600,
                contentColor = Color.White,
                modifier = Modifier.testTag("mock_fab_add")
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Add Mock Exam")
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 90.dp)
        ) {
            // Scoreboard Summary Cards
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Card(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text("Highest Score", style = MaterialTheme.typography.labelSmall.copy(color = Slate400))
                            Text("%.1f".format(highestScore), style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = SuccessEmerald))
                        }
                    }
                    Card(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text("Average Score", style = MaterialTheme.typography.labelSmall.copy(color = Slate400))
                            Text("%.1f".format(averageScore), style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = BrandIndigo600))
                        }
                    }
                }
            }

            item {
                Text(
                    text = "Examination History",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                )
            }

            if (mockExams.isEmpty()) {
                item {
                    Text(
                        text = "No mock tests recorded yet. Tap '+' to record your first Model Test score.",
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant),
                        modifier = Modifier.padding(vertical = 10.dp)
                    )
                }
            } else {
                items(mockExams, key = { it.id }) { exam ->
                    val sdf = SimpleDateFormat("MMM d, yyyy", Locale.getDefault())
                    val dateStr = sdf.format(Date(exam.examDateMillis))

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(16.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = exam.examName,
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Text(
                                        text = "$dateStr • ${exam.timeTakenMinutes} minutes",
                                        style = MaterialTheme.typography.labelSmall.copy(color = Slate400)
                                    )
                                }
                                Surface(
                                    color = if (exam.marksObtained >= 130) SuccessEmerald.copy(alpha = 0.15f) else WarningAmber.copy(alpha = 0.15f),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text(
                                        text = "%.1f / %.0f".format(exam.marksObtained, exam.totalMarks),
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            color = if (exam.marksObtained >= 130) SuccessEmerald else WarningAmber,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Correct: ${exam.correctAnswers}",
                                    style = MaterialTheme.typography.bodySmall.copy(color = SuccessEmerald)
                                )
                                Text(
                                    text = "Negative Deduction: -%.1f".format(exam.negativeMarks),
                                    style = MaterialTheme.typography.bodySmall.copy(color = AlertRose)
                                )
                            }

                            if (exam.comments.isNotBlank()) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "Analysis: ${exam.comments}",
                                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Add Mock Exam Dialog
        if (showAddExamDialog) {
            AlertDialog(
                onDismissRequest = { showAddExamDialog = false },
                title = { Text("Record Model Test Result") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = examName,
                            onValueChange = { examName = it },
                            label = { Text("Model Test Title") },
                            placeholder = { Text("e.g. 47th BCS Full Model Test #2") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = marksObtainedStr,
                                onValueChange = { marksObtainedStr = it },
                                label = { Text("Marks Obtained") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = totalMarksStr,
                                onValueChange = { totalMarksStr = it },
                                label = { Text("Total Marks") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = correctCountStr,
                                onValueChange = { correctCountStr = it },
                                label = { Text("Correct Answers") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = negativeMarksStr,
                                onValueChange = { negativeMarksStr = it },
                                label = { Text("Negative Marks") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }
                        OutlinedTextField(
                            value = commentsStr,
                            onValueChange = { commentsStr = it },
                            label = { Text("Performance Comments & Weak Subjects") },
                            maxLines = 2,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (examName.isNotBlank()) {
                                val obtained = marksObtainedStr.toFloatOrNull() ?: 120f
                                val total = totalMarksStr.toFloatOrNull() ?: 200f
                                val correct = correctCountStr.toIntOrNull() ?: 140
                                val neg = negativeMarksStr.toFloatOrNull() ?: 10f
                                coroutineScope.launch {
                                    viewModel.repository.addMockExam(
                                        MockExam(
                                            examName = examName,
                                            examDateMillis = System.currentTimeMillis(),
                                            totalMarks = total,
                                            marksObtained = obtained,
                                            correctAnswers = correct,
                                            negativeMarks = neg,
                                            timeTakenMinutes = 120,
                                            comments = commentsStr
                                        )
                                    )
                                    examName = ""
                                    commentsStr = ""
                                    showAddExamDialog = false
                                }
                            }
                        }
                    ) {
                        Text("Save Result")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showAddExamDialog = false }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}
