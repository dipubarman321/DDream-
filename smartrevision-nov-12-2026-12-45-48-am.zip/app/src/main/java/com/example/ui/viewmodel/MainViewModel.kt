package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.*
import com.example.data.repository.StudyRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Calendar

enum class PomodoroMode(val title: String, val defaultMinutes: Int) {
    WORK("Study Session", 25),
    SHORT_BREAK("Short Break", 5),
    LONG_BREAK("Long Break", 15)
}

enum class RevisionTab {
    TODAY, UPCOMING, COMPLETED, OVERDUE
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    val repository = StudyRepository(db)

    // Data streams
    val userProfile: StateFlow<UserProfile?> = repository.userProfile
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val subjects: StateFlow<List<Subject>> = repository.subjects
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allTopics: StateFlow<List<Topic>> = repository.allTopics
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val studySessions: StateFlow<List<StudySession>> = repository.studySessions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allRevisions: StateFlow<List<RevisionSchedule>> = repository.allRevisions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val todayPendingRevisions: StateFlow<List<RevisionSchedule>> = repository.getTodayPendingRevisions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val upcomingRevisions: StateFlow<List<RevisionSchedule>> = repository.getUpcomingRevisions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val completedRevisions: StateFlow<List<RevisionSchedule>> = repository.getCompletedRevisions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val overdueRevisions: StateFlow<List<RevisionSchedule>> = repository.getOverdueRevisions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val focusSessions: StateFlow<List<FocusSession>> = repository.focusSessions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val blockedApps: StateFlow<List<BlockedApp>> = repository.blockedApps
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val studyNotes: StateFlow<List<StudyNote>> = repository.studyNotes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val mcqSessions: StateFlow<List<McqSession>> = repository.mcqSessions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val mockExams: StateFlow<List<MockExam>> = repository.mockExams
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val vocabulary: StateFlow<List<VocabularyWord>> = repository.vocabulary
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val examCountdowns: StateFlow<List<ExamCountdown>> = repository.examCountdowns
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notifications: StateFlow<List<AppNotification>> = repository.notifications
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val unreadNotificationsCount: StateFlow<Int> = repository.unreadNotificationCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val transactions: StateFlow<List<PaymentTransaction>> = repository.transactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Navigation and screen state
    var currentScreen = MutableStateFlow("dashboard")
        private set

    fun navigateTo(route: String) {
        currentScreen.value = route
    }

    // STUDY TIMER / STOPWATCH STATE
    private val _studyTimerSeconds = MutableStateFlow(0)
    val studyTimerSeconds: StateFlow<Int> = _studyTimerSeconds

    private val _isStudyTimerRunning = MutableStateFlow(false)
    val isStudyTimerRunning: StateFlow<Boolean> = _isStudyTimerRunning

    val selectedStudySubject = MutableStateFlow<Subject?>(null)
    val selectedStudyTopic = MutableStateFlow<Topic?>(null)
    val studySessionNotes = MutableStateFlow("")
    val autoScheduleAfterStudy = MutableStateFlow(true)
    private var studyTimerJob: Job? = null

    fun startStudyTimer() {
        if (_isStudyTimerRunning.value) return
        _isStudyTimerRunning.value = true
        studyTimerJob = viewModelScope.launch {
            while (_isStudyTimerRunning.value) {
                delay(1000)
                _studyTimerSeconds.value += 1
            }
        }
    }

    fun pauseStudyTimer() {
        _isStudyTimerRunning.value = false
        studyTimerJob?.cancel()
    }

    fun stopAndSaveStudySession(onSaved: () -> Unit = {}) {
        pauseStudyTimer()
        val durationMins = maxOf(1, _studyTimerSeconds.value / 60)
        val subject = selectedStudySubject.value
        val topic = selectedStudyTopic.value

        viewModelScope.launch {
            repository.recordStudySession(
                subjectId = subject?.id ?: 1L,
                chapterId = topic?.chapterId,
                topicId = topic?.id,
                subjectName = subject?.title ?: "General Study",
                chapterName = "",
                topicName = topic?.title ?: "Open Study Session",
                durationMinutes = durationMins,
                notes = studySessionNotes.value,
                sessionType = "Timer",
                autoScheduleRevision = autoScheduleAfterStudy.value
            )
            _studyTimerSeconds.value = 0
            studySessionNotes.value = ""
            onSaved()
        }
    }

    fun resetStudyTimer() {
        pauseStudyTimer()
        _studyTimerSeconds.value = 0
    }

    // POMODORO STATE
    val pomodoroMode = MutableStateFlow(PomodoroMode.WORK)
    val pomodoroWorkDurationMinutes = MutableStateFlow(25)
    val pomodoroShortBreakMinutes = MutableStateFlow(5)
    val pomodoroLongBreakMinutes = MutableStateFlow(15)
    val pomodoroSecondsLeft = MutableStateFlow(25 * 60)
    val isPomodoroRunning = MutableStateFlow(false)
    val completedPomodorosToday = MutableStateFlow(3)
    val targetPomodorosDaily = MutableStateFlow(8)
    private var pomodoroJob: Job? = null

    fun togglePomodoro() {
        if (isPomodoroRunning.value) {
            isPomodoroRunning.value = false
            pomodoroJob?.cancel()
        } else {
            isPomodoroRunning.value = true
            pomodoroJob = viewModelScope.launch {
                while (isPomodoroRunning.value && pomodoroSecondsLeft.value > 0) {
                    delay(1000)
                    pomodoroSecondsLeft.value -= 1
                }
                if (pomodoroSecondsLeft.value <= 0) {
                    isPomodoroRunning.value = false
                    // Handle transition
                    if (pomodoroMode.value == PomodoroMode.WORK) {
                        completedPomodorosToday.value += 1
                        pomodoroMode.value = if (completedPomodorosToday.value % 4 == 0) PomodoroMode.LONG_BREAK else PomodoroMode.SHORT_BREAK
                        pomodoroSecondsLeft.value = (if (pomodoroMode.value == PomodoroMode.LONG_BREAK) pomodoroLongBreakMinutes.value else pomodoroShortBreakMinutes.value) * 60
                    } else {
                        pomodoroMode.value = PomodoroMode.WORK
                        pomodoroSecondsLeft.value = pomodoroWorkDurationMinutes.value * 60
                    }
                }
            }
        }
    }

    fun resetPomodoro() {
        isPomodoroRunning.value = false
        pomodoroJob?.cancel()
        pomodoroSecondsLeft.value = pomodoroWorkDurationMinutes.value * 60
        pomodoroMode.value = PomodoroMode.WORK
    }

    // STRICT FOCUS MODE STATE
    val focusTargetMinutes = MutableStateFlow(50)
    val focusSecondsLeft = MutableStateFlow(50 * 60)
    val isFocusRunning = MutableStateFlow(false)
    val isStrictModeActive = MutableStateFlow(true)
    val focusSubjectName = MutableStateFlow("Bangladesh Affairs")
    val focusTopicName = MutableStateFlow("Constitutional Framework & History")
    val focusInterruptionsCount = MutableStateFlow(0)
    private var focusJob: Job? = null

    fun startFocusSession(minutes: Int) {
        focusTargetMinutes.value = minutes
        focusSecondsLeft.value = minutes * 60
        isFocusRunning.value = true
        focusJob?.cancel()
        focusJob = viewModelScope.launch {
            while (isFocusRunning.value && focusSecondsLeft.value > 0) {
                delay(1000)
                focusSecondsLeft.value -= 1
            }
            if (focusSecondsLeft.value <= 0) {
                isFocusRunning.value = false
                repository.recordFocusSession(
                    targetMinutes = focusTargetMinutes.value,
                    completedMinutes = focusTargetMinutes.value,
                    isCompleted = true,
                    isInterrupted = false,
                    reason = "",
                    subjectName = focusSubjectName.value,
                    topicName = focusTopicName.value
                )
            }
        }
    }

    fun interruptFocusSession(reason: String) {
        val completedMinutes = (focusTargetMinutes.value * 60 - focusSecondsLeft.value) / 60
        isFocusRunning.value = false
        focusJob?.cancel()
        focusInterruptionsCount.value += 1
        viewModelScope.launch {
            repository.recordFocusSession(
                targetMinutes = focusTargetMinutes.value,
                completedMinutes = completedMinutes,
                isCompleted = false,
                isInterrupted = true,
                reason = reason,
                subjectName = focusSubjectName.value,
                topicName = focusTopicName.value
            )
        }
    }

    // REVISION ACTIONS
    val selectedRevisionTab = MutableStateFlow(RevisionTab.TODAY)
    val revisionSchedulingMode = MutableStateFlow(RevisionMode.MODE_A_FIXED)

    fun markRevisionComplete(revision: RevisionSchedule, notes: String, rating: Int) {
        viewModelScope.launch {
            repository.completeRevision(revision, notes, rating)
        }
    }

    fun rescheduleRevision(revisionId: Long, additionalDays: Int) {
        viewModelScope.launch {
            val newDate = System.currentTimeMillis() + (additionalDays * 86_400_000L)
            repository.rescheduleRevision(revisionId, newDate)
        }
    }

    // Interactive Quiz State
    val quizCurrentIndex = MutableStateFlow(0)
    val quizSelectedOption = MutableStateFlow<Int?>(null)
    val quizScore = MutableStateFlow(0)
    val quizIsFinished = MutableStateFlow(false)

    // Flashcard index
    val flashcardIndex = MutableStateFlow(0)
    val isFlashcardFlipped = MutableStateFlow(false)

    init {
        // Preload any data check if needed
    }
}
