package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.RevisionMode
import com.example.data.model.RevisionSchedule
import com.example.ui.components.AppHeader
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.RevisionTab
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RevisionScreen(
    viewModel: MainViewModel,
    onMenuClick: () -> Unit
) {
    val selectedTab by viewModel.selectedRevisionTab.collectAsState()
    val schedulingMode by viewModel.revisionSchedulingMode.collectAsState()
    val todayPending by viewModel.todayPendingRevisions.collectAsState()
    val upcoming by viewModel.upcomingRevisions.collectAsState()
    val completed by viewModel.completedRevisions.collectAsState()
    val overdue by viewModel.overdueRevisions.collectAsState()
    val unreadNotifications by viewModel.unreadNotificationsCount.collectAsState()
    val subjects by viewModel.subjects.collectAsState()
    val coroutineScope = rememberCoroutineScope()

    var showCompleteDialog by remember { mutableStateOf<RevisionSchedule?>(null) }
    var completeNotes by remember { mutableStateOf("") }
    var completeRating by remember { mutableStateOf(5) }

    var showRescheduleDialog by remember { mutableStateOf<RevisionSchedule?>(null) }
    var showNewRevisionDialog by remember { mutableStateOf(false) }

    // Custom new revision state
    var newTopicName by remember { mutableStateOf("") }
    var newSubjectId by remember { mutableStateOf<Long?>(null) }
    var interval4Selected by remember { mutableStateOf(true) }
    var interval7Selected by remember { mutableStateOf(true) }
    var interval10Selected by remember { mutableStateOf(true) }

    val currentList = when (selectedTab) {
        RevisionTab.TODAY -> todayPending
        RevisionTab.UPCOMING -> upcoming
        RevisionTab.COMPLETED -> completed
        RevisionTab.OVERDUE -> overdue
    }

    Scaffold(
        topBar = {
            AppHeader(
                title = "Smart Revision Planner",
                subtitle = "Spaced Repetition (4-7-10 Days)",
                onMenuClick = onMenuClick,
                unreadNotifications = unreadNotifications,
                onNotificationsClick = { viewModel.navigateTo("notifications") }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showNewRevisionDialog = true },
                containerColor = SuccessEmerald,
                contentColor = Color.White,
                modifier = Modifier.testTag("revision_fab_new")
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Schedule Revision")
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 90.dp)
        ) {
            // 1. Spaced Repetition Mode Selector
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Scheduling Algorithm",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                            )
                            Surface(
                                color = BrandIndigo100,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = if (schedulingMode == RevisionMode.MODE_A_FIXED) "Mode A: Fixed" else "Mode B: Sequential",
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = BrandIndigo600,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (schedulingMode == RevisionMode.MODE_A_FIXED)
                                "Mode A (Fixed Interval): Dates are calculated from original study date (+4, +7, +10 days)."
                            else
                                "Mode B (Sequential): Each subsequent revision is calculated from actual completion date of the previous revision.",
                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FilterChip(
                                selected = schedulingMode == RevisionMode.MODE_A_FIXED,
                                onClick = { viewModel.revisionSchedulingMode.value = RevisionMode.MODE_A_FIXED },
                                label = { Text("Mode A (Fixed)") },
                                modifier = Modifier.weight(1f)
                            )
                            FilterChip(
                                selected = schedulingMode == RevisionMode.MODE_B_SEQUENTIAL,
                                onClick = { viewModel.revisionSchedulingMode.value = RevisionMode.MODE_B_SEQUENTIAL },
                                label = { Text("Mode B (Sequential)") },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // 2. Revision Tabs: Today, Upcoming, Completed, Overdue
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    RevisionTabButton(
                        title = "Today",
                        count = todayPending.size,
                        isSelected = selectedTab == RevisionTab.TODAY,
                        color = WarningAmber,
                        onClick = { viewModel.selectedRevisionTab.value = RevisionTab.TODAY },
                        modifier = Modifier.weight(1f)
                    )
                    RevisionTabButton(
                        title = "Upcoming",
                        count = upcoming.size,
                        isSelected = selectedTab == RevisionTab.UPCOMING,
                        color = InfoCyan,
                        onClick = { viewModel.selectedRevisionTab.value = RevisionTab.UPCOMING },
                        modifier = Modifier.weight(1f)
                    )
                    RevisionTabButton(
                        title = "Overdue",
                        count = overdue.size,
                        isSelected = selectedTab == RevisionTab.OVERDUE,
                        color = AlertRose,
                        onClick = { viewModel.selectedRevisionTab.value = RevisionTab.OVERDUE },
                        modifier = Modifier.weight(1f)
                    )
                    RevisionTabButton(
                        title = "Done",
                        count = completed.size,
                        isSelected = selectedTab == RevisionTab.COMPLETED,
                        color = SuccessEmerald,
                        onClick = { viewModel.selectedRevisionTab.value = RevisionTab.COMPLETED },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // 3. Revision Cards List
            if (currentList.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircleOutline,
                                contentDescription = null,
                                tint = SuccessEmerald,
                                modifier = Modifier.size(40.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "No revisions in ${selectedTab.name.lowercase().replaceFirstChar { it.uppercase() }}",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "All set! You can schedule new topic revisions using the '+' button.",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                            )
                        }
                    }
                }
            } else {
                items(currentList, key = { it.id }) { rev ->
                    val sdf = SimpleDateFormat("MMM d, yyyy", Locale.getDefault())
                    val scheduledDateStr = sdf.format(Date(rev.scheduledDateMillis))
                    val originalDateStr = sdf.format(Date(rev.originalStudyDateMillis))

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("revision_card_${rev.id}"),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(16.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Top
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = rev.topicName,
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = rev.subjectName,
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = BrandIndigo600,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    )
                                }
                                Surface(
                                    color = BrandIndigo100,
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = "${rev.intervalDays} Days",
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = BrandIndigo600,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(
                                        text = "Original Study",
                                        style = MaterialTheme.typography.labelSmall.copy(color = Slate400)
                                    )
                                    Text(
                                        text = originalDateStr,
                                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium)
                                    )
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = if (rev.isCompleted) "Completed Date" else "Due Date",
                                        style = MaterialTheme.typography.labelSmall.copy(color = Slate400)
                                    )
                                    Text(
                                        text = if (rev.isCompleted && rev.completedDateMillis != null)
                                            sdf.format(Date(rev.completedDateMillis))
                                        else scheduledDateStr,
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = if (rev.isCompleted) SuccessEmerald else if (selectedTab == RevisionTab.OVERDUE) AlertRose else MaterialTheme.colorScheme.onSurface
                                        )
                                    )
                                }
                            }

                            if (rev.revisionNotes.isNotBlank()) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Notes: ${rev.revisionNotes}",
                                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                )
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // Action buttons
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (!rev.isCompleted) {
                                    OutlinedButton(
                                        onClick = { showRescheduleDialog = rev },
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.height(34.dp),
                                        contentPadding = PaddingValues(horizontal = 10.dp)
                                    ) {
                                        Text("Reschedule", fontSize = 12.sp)
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Button(
                                        onClick = {
                                            showCompleteDialog = rev
                                            completeRating = 5
                                            completeNotes = ""
                                        },
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.height(34.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = SuccessEmerald),
                                        contentPadding = PaddingValues(horizontal = 12.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Complete", fontSize = 12.sp)
                                    }
                                } else {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        repeat(rev.rating) {
                                            Icon(
                                                imageVector = Icons.Default.Star,
                                                contentDescription = null,
                                                tint = GoldStar,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "Completed ✓",
                                            style = MaterialTheme.typography.labelMedium.copy(
                                                color = SuccessEmerald,
                                                fontWeight = FontWeight.Bold
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Complete Revision Dialog
        if (showCompleteDialog != null) {
            val rev = showCompleteDialog!!
            AlertDialog(
                onDismissRequest = { showCompleteDialog = null },
                title = { Text("Complete Revision") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(
                            text = "Rate your recall quality for '${rev.topicName}':",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Row(
                            horizontalArrangement = Arrangement.Center,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            (1..5).forEach { star ->
                                IconButton(onClick = { completeRating = star }) {
                                    Icon(
                                        imageVector = if (star <= completeRating) Icons.Default.Star else Icons.Default.StarBorder,
                                        contentDescription = "$star Stars",
                                        tint = GoldStar,
                                        modifier = Modifier.size(32.dp)
                                    )
                                }
                            }
                        }
                        OutlinedTextField(
                            value = completeNotes,
                            onValueChange = { completeNotes = it },
                            label = { Text("Recall Notes & Key Formulas") },
                            placeholder = { Text("What points did you remember? Any gaps?") },
                            maxLines = 3,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.markRevisionComplete(rev, completeNotes, completeRating)
                            showCompleteDialog = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = SuccessEmerald)
                    ) {
                        Text("Record & Done")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showCompleteDialog = null }) {
                        Text("Cancel")
                    }
                }
            )
        }

        // Reschedule Dialog
        if (showRescheduleDialog != null) {
            val rev = showRescheduleDialog!!
            AlertDialog(
                onDismissRequest = { showRescheduleDialog = null },
                title = { Text("Reschedule Revision") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Shift '${rev.topicName}' to a later date:")
                        Button(
                            onClick = {
                                viewModel.rescheduleRevision(rev.id, 1)
                                showRescheduleDialog = null
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Postpone by 1 Day (Tomorrow)")
                        }
                        Button(
                            onClick = {
                                viewModel.rescheduleRevision(rev.id, 3)
                                showRescheduleDialog = null
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Postpone by 3 Days")
                        }
                        Button(
                            onClick = {
                                viewModel.rescheduleRevision(rev.id, 7)
                                showRescheduleDialog = null
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Postpone by 1 Week")
                        }
                    }
                },
                confirmButton = {},
                dismissButton = {
                    TextButton(onClick = { showRescheduleDialog = null }) {
                        Text("Close")
                    }
                }
            )
        }

        // Schedule New Custom Revision Dialog
        if (showNewRevisionDialog) {
            AlertDialog(
                onDismissRequest = { showNewRevisionDialog = false },
                title = { Text("Schedule 4-7-10 Revisions") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = newTopicName,
                            onValueChange = { newTopicName = it },
                            label = { Text("Topic to Revise") },
                            placeholder = { Text("e.g. Bangladesh Constitution Writ Jurisdiction") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text("Select Intervals to Schedule:", style = MaterialTheme.typography.bodySmall)
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            FilterChip(
                                selected = interval4Selected,
                                onClick = { interval4Selected = !interval4Selected },
                                label = { Text("4 Days") }
                            )
                            FilterChip(
                                selected = interval7Selected,
                                onClick = { interval7Selected = !interval7Selected },
                                label = { Text("7 Days") }
                            )
                            FilterChip(
                                selected = interval10Selected,
                                onClick = { interval10Selected = !interval10Selected },
                                label = { Text("10 Days") }
                            )
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (newTopicName.isNotBlank()) {
                                val selectedIntervals = mutableListOf<Int>()
                                if (interval4Selected) selectedIntervals.add(4)
                                if (interval7Selected) selectedIntervals.add(7)
                                if (interval10Selected) selectedIntervals.add(10)
                                if (selectedIntervals.isEmpty()) selectedIntervals.add(4)

                                val sub = subjects.firstOrNull()
                                coroutineScope.launch {
                                    viewModel.repository.scheduleSmartRevisions(
                                        topicId = 1L,
                                        subjectId = sub?.id ?: 1L,
                                        topicName = newTopicName,
                                        subjectName = sub?.title ?: "Bangladesh Affairs",
                                        chapterName = "",
                                        intervals = selectedIntervals,
                                        mode = schedulingMode
                                    )
                                    newTopicName = ""
                                    showNewRevisionDialog = false
                                }
                            }
                        }
                    ) {
                        Text("Schedule")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showNewRevisionDialog = false }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}

@Composable
fun RevisionTabButton(
    title: String,
    count: Int,
    isSelected: Boolean,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = if (isSelected) color.copy(alpha = 0.18f) else MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(
            width = if (isSelected) 1.5.dp else 1.dp,
            color = if (isSelected) color else Slate200
        ),
        modifier = modifier
            .clickable { onClick() }
            .testTag("revision_tab_$title")
    ) {
        Column(
            modifier = Modifier.padding(vertical = 10.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "$count",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.ExtraBold,
                    color = if (isSelected) color else MaterialTheme.colorScheme.onSurface
                )
            )
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                    color = if (isSelected) color else MaterialTheme.colorScheme.onSurfaceVariant
                )
            )
        }
    }
}
