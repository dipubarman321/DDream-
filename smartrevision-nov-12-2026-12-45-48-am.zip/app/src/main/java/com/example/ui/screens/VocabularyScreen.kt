package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MasteryLevel
import com.example.data.model.VocabularyWord
import com.example.ui.components.AppHeader
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VocabularyScreen(
    viewModel: MainViewModel,
    onMenuClick: () -> Unit
) {
    val vocabulary by viewModel.vocabulary.collectAsState()
    val unreadNotifications by viewModel.unreadNotificationsCount.collectAsState()
    val coroutineScope = rememberCoroutineScope()

    var activeTab by remember { mutableStateOf("LIST") } // "LIST" or "FLASHCARD"
    var flashcardIndex by remember { mutableStateOf(0) }
    var isFlipped by remember { mutableStateOf(false) }
    val rotation by animateFloatAsState(targetValue = if (isFlipped) 180f else 0f, label = "flip")

    var searchQuery by remember { mutableStateOf("") }
    var showAddWordDialog by remember { mutableStateOf(false) }

    var newWord by remember { mutableStateOf("") }
    var newBengaliMeaning by remember { mutableStateOf("") }
    var newDefinition by remember { mutableStateOf("") }
    var newSynonyms by remember { mutableStateOf("") }
    var newExample by remember { mutableStateOf("") }

    val filteredList = vocabulary.filter {
        searchQuery.isBlank() ||
                it.word.contains(searchQuery, ignoreCase = true) ||
                it.bengaliMeaning.contains(searchQuery, ignoreCase = true)
    }

    val masteredCount = vocabulary.count { it.masteryLevel == MasteryLevel.MASTERED }

    Scaffold(
        topBar = {
            AppHeader(
                title = "English Vocabulary Lab",
                subtitle = "${vocabulary.size} High-Yield Exam Words • $masteredCount Mastered",
                onMenuClick = onMenuClick,
                unreadNotifications = unreadNotifications,
                onNotificationsClick = { viewModel.navigateTo("notifications") }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddWordDialog = true },
                containerColor = PurpleAccent,
                contentColor = Color.White,
                modifier = Modifier.testTag("vocab_fab_add")
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Add Word")
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 90.dp)
        ) {
            // Mode Switcher: Word List vs Flashcards
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = activeTab == "LIST",
                        onClick = { activeTab = "LIST" },
                        label = { Text("Word List (${vocabulary.size})") },
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = activeTab == "FLASHCARD",
                        onClick = {
                            activeTab = "FLASHCARD"
                            isFlipped = false
                        },
                        label = { Text("Interactive Flashcards 🎴") },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            if (activeTab == "FLASHCARD" && vocabulary.isNotEmpty()) {
                item {
                    val currentWord = vocabulary.getOrElse(flashcardIndex.coerceIn(0, vocabulary.size - 1)) { vocabulary.first() }
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(280.dp)
                            .graphicsLayer {
                                rotationY = rotation
                                cameraDistance = 12f * density
                            }
                            .clickable { isFlipped = !isFlipped }
                            .testTag("flashcard_interactive_card"),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isFlipped) BrandNavy900 else MaterialTheme.colorScheme.surface
                        ),
                        shape = RoundedCornerShape(24.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            if (!isFlipped) {
                                // Front: English Word
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Surface(
                                        color = PurpleAccent.copy(alpha = 0.15f),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Text(
                                            text = "TAP TO FLIP BENGALI MEANING",
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = PurpleAccent,
                                                fontWeight = FontWeight.Bold
                                            )
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(24.dp))
                                    Text(
                                        text = currentWord.word,
                                        style = MaterialTheme.typography.headlineMedium.copy(
                                            fontWeight = FontWeight.ExtraBold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = currentWord.definition,
                                        style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant),
                                        textAlign = TextAlign.Center
                                    )
                                }
                            } else {
                                // Back: Bengali Meaning & Examples (Rotated back)
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.graphicsLayer { rotationY = 180f }
                                ) {
                                    Text(
                                        text = currentWord.bengaliMeaning,
                                        fontSize = 24.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = WarningAmber,
                                        textAlign = TextAlign.Center
                                    )
                                    Spacer(modifier = Modifier.height(14.dp))
                                    Text(
                                        text = "Synonyms: ${currentWord.synonyms}",
                                        style = MaterialTheme.typography.bodySmall.copy(color = Color.White),
                                        textAlign = TextAlign.Center
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = "\"${currentWord.exampleSentence}\"",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = Slate400,
                                            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                                        ),
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }
                    }
                }

                // Flashcard navigator buttons
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = {
                                if (flashcardIndex > 0) {
                                    flashcardIndex -= 1
                                    isFlipped = false
                                }
                            },
                            enabled = flashcardIndex > 0,
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("← Previous")
                        }

                        Text(
                            text = "${flashcardIndex + 1} / ${vocabulary.size}",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                        )

                        Button(
                            onClick = {
                                if (flashcardIndex < vocabulary.size - 1) {
                                    flashcardIndex += 1
                                    isFlipped = false
                                }
                            },
                            enabled = flashcardIndex < vocabulary.size - 1,
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Next →")
                        }
                    }
                }
            } else {
                // Word List View
                item {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Search word or Bengali meaning...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        singleLine = true
                    )
                }

                items(filteredList, key = { it.id }) { word ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(16.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = word.word,
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Text(
                                        text = word.bengaliMeaning,
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            color = BrandIndigo600,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                }
                                Surface(
                                    color = if (word.masteryLevel == MasteryLevel.MASTERED) SuccessEmerald.copy(alpha = 0.15f) else WarningAmber.copy(alpha = 0.15f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = word.masteryLevel.name,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = if (word.masteryLevel == MasteryLevel.MASTERED) SuccessEmerald else WarningAmber
                                        )
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = word.definition,
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                            )

                            if (word.exampleSentence.isNotBlank()) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "Example: \"${word.exampleSentence}\"",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = Slate600,
                                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                                    )
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))
                            Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                                TextButton(
                                    onClick = {
                                        val nextLevel = when (word.masteryLevel) {
                                            MasteryLevel.LEARNING -> MasteryLevel.REVIEWING
                                            MasteryLevel.REVIEWING -> MasteryLevel.MASTERED
                                            MasteryLevel.MASTERED -> MasteryLevel.LEARNING
                                        }
                                        coroutineScope.launch {
                                            viewModel.repository.updateWordMastery(word.id, nextLevel, System.currentTimeMillis() + 86_400_000L * 4)
                                        }
                                    }
                                ) {
                                    Text("Mark ${if (word.masteryLevel == MasteryLevel.MASTERED) "Review" else "Mastered ✓"}", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Add Word Dialog
        if (showAddWordDialog) {
            AlertDialog(
                onDismissRequest = { showAddWordDialog = false },
                title = { Text("Add Vocabulary Word") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = newWord,
                            onValueChange = { newWord = it },
                            label = { Text("English Word") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = newBengaliMeaning,
                            onValueChange = { newBengaliMeaning = it },
                            label = { Text("Bengali Meaning (বাংলা অর্থ)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = newDefinition,
                            onValueChange = { newDefinition = it },
                            label = { Text("English Definition") },
                            maxLines = 2,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = newSynonyms,
                            onValueChange = { newSynonyms = it },
                            label = { Text("Synonyms") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = newExample,
                            onValueChange = { newExample = it },
                            label = { Text("Example Sentence") },
                            maxLines = 2,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (newWord.isNotBlank() && newBengaliMeaning.isNotBlank()) {
                                coroutineScope.launch {
                                    viewModel.repository.addVocabularyWord(
                                        VocabularyWord(
                                            word = newWord,
                                            bengaliMeaning = newBengaliMeaning,
                                            definition = newDefinition,
                                            synonyms = newSynonyms,
                                            exampleSentence = newExample
                                        )
                                    )
                                    newWord = ""
                                    newBengaliMeaning = ""
                                    newDefinition = ""
                                    newSynonyms = ""
                                    newExample = ""
                                    showAddWordDialog = false
                                }
                            }
                        }
                    ) {
                        Text("Add Word")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showAddWordDialog = false }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}
