package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.AppHeader
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FocusModeScreen(
    viewModel: MainViewModel,
    onMenuClick: () -> Unit
) {
    val isFocusRunning by viewModel.isFocusRunning.collectAsState()
    val secondsLeft by viewModel.focusSecondsLeft.collectAsState()
    val targetMinutes by viewModel.focusTargetMinutes.collectAsState()
    val isStrictMode by viewModel.isStrictModeActive.collectAsState()
    val subjectName by viewModel.focusSubjectName.collectAsState()
    val topicName by viewModel.focusTopicName.collectAsState()
    val blockedApps by viewModel.blockedApps.collectAsState()
    val interruptionsCount by viewModel.focusInterruptionsCount.collectAsState()
    val unreadNotifications by viewModel.unreadNotificationsCount.collectAsState()
    val coroutineScope = rememberCoroutineScope()

    var showEmergencyExitDialog by remember { mutableStateOf(false) }
    var emergencyExitReason by remember { mutableStateOf("") }
    var showAddBlockAppDialog by remember { mutableStateOf(false) }
    var newAppName by remember { mutableStateOf("") }
    var newAppCategory by remember { mutableStateOf("Social Media") }

    val quotes = listOf(
        "\"Focus is a muscle; every minute of resistance makes your intellect stronger.\" — BCS Cadre Preparation",
        "\"Distraction is the enemy of mastery. One hour of deep work exceeds six hours of shallow browsing.\"",
        "\"Your future in the Civil Service is forged in the silence of unbroken concentration.\"",
        "\"Discipline is choosing between what you want now and what you want most.\""
    )
    val randomQuote = remember { quotes.random() }

    val mins = secondsLeft / 60
    val secs = secondsLeft % 60
    val formattedTime = "%02d:%02d".format(mins, secs)
    val progress = if (targetMinutes > 0) {
        ((targetMinutes * 60 - secondsLeft).toFloat() / (targetMinutes * 60)).coerceIn(0f, 1f)
    } else 0f

    Scaffold(
        topBar = {
            AppHeader(
                title = "Strict Focus & App Blocker",
                subtitle = if (isFocusRunning) "ACTIVE FOCUS LOCK • Distractions Restricted" else "Deep Work Concentration Suite",
                onMenuClick = onMenuClick,
                unreadNotifications = unreadNotifications,
                onNotificationsClick = { viewModel.navigateTo("notifications") }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 90.dp)
        ) {
            // 1. Focus Timer Display / Active Shield
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("focus_timer_card"),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isFocusRunning) BrandNavy900 else MaterialTheme.colorScheme.surface
                    ),
                    shape = RoundedCornerShape(24.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Status Badge
                        Surface(
                            color = if (isFocusRunning) AlertRose.copy(alpha = 0.2f) else SuccessEmerald.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (isFocusRunning) Icons.Default.Lock else Icons.Default.Shield,
                                    contentDescription = null,
                                    tint = if (isFocusRunning) AlertRose else SuccessEmerald,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (isFocusRunning) "STRICT LOCK ACTIVE" else "SHIELD READY",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.ExtraBold,
                                        color = if (isFocusRunning) AlertRose else SuccessEmerald
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        // Large Circular Countdown
                        Box(
                            modifier = Modifier
                                .size(200.dp)
                                .clip(CircleShape)
                                .background(if (isFocusRunning) Color(0xFF131B2E) else Slate100)
                                .border(
                                    width = 6.dp,
                                    color = if (isFocusRunning) AlertRose else BrandIndigo600,
                                    shape = CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = formattedTime,
                                    fontSize = 44.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontFamily = FontFamily.Monospace,
                                    color = if (isFocusRunning) Color.White else MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "$targetMinutes MIN TARGET",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = if (isFocusRunning) Slate400 else Slate600,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = topicName,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (isFocusRunning) Color.White else MaterialTheme.colorScheme.onSurface
                            ),
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = subjectName,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = if (isFocusRunning) SuccessEmerald else BrandIndigo600,
                                fontWeight = FontWeight.SemiBold
                            )
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = randomQuote,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = if (isFocusRunning) Slate400 else MaterialTheme.colorScheme.onSurfaceVariant,
                                fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                            ),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        // Start / Emergency Exit controls
                        if (!isFocusRunning) {
                            Text(
                                text = "Choose Session Duration",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = { viewModel.startFocusSession(25) },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text("25m")
                                }
                                Button(
                                    onClick = { viewModel.startFocusSession(50) },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = BrandIndigo600)
                                ) {
                                    Text("50m")
                                }
                                Button(
                                    onClick = { viewModel.startFocusSession(90) },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text("90m")
                                }
                            }
                        } else {
                            OutlinedButton(
                                onClick = { showEmergencyExitDialog = true },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("focus_emergency_exit_button"),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = AlertRose)
                            ) {
                                Icon(imageVector = Icons.Default.Warning, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Emergency Exit (Penalty Logged)")
                            }
                        }
                    }
                }
            }

            // 2. Strict Social Media & Website App Distraction Blocker
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Distraction App Blocker",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "${blockedApps.count { it.isBlocked }} apps restricted during focus sessions",
                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                    }
                    IconButton(onClick = { showAddBlockAppDialog = true }) {
                        Icon(imageVector = Icons.Default.AddCircleOutline, contentDescription = "Add Blocked App", tint = BrandIndigo600)
                    }
                }
            }

            // List of blocked apps
            items(blockedApps, key = { it.id }) { app ->
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(14.dp),
                    tonalElevation = 1.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(
                                        if (app.isBlocked) AlertRose.copy(alpha = 0.15f) else Slate200,
                                        CircleShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (app.isBlocked) Icons.Default.Block else Icons.Default.Check,
                                    contentDescription = null,
                                    tint = if (app.isBlocked) AlertRose else Slate600,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = app.appName,
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "${app.category} • ${if (app.isBlocked) "Blocked in Focus" else "Allowed"}",
                                    style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                )
                            }
                        }
                        Switch(
                            checked = app.isBlocked,
                            onCheckedChange = { isChecked ->
                                coroutineScope.launch {
                                    viewModel.repository.toggleBlockedApp(app.id, isChecked)
                                }
                            }
                        )
                    }
                }
            }

            // 3. Android Blocker Compliance Notice
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Slate100),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = BrandIndigo600,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "System Distraction Enforcement",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "This application monitors background distraction events. When strict mode is active, opening configured social media applications triggers an immediate focus alert and records interruption penalties.",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                            )
                        }
                    }
                }
            }
        }

        // Emergency Exit Dialog
        if (showEmergencyExitDialog) {
            AlertDialog(
                onDismissRequest = { showEmergencyExitDialog = false },
                title = { Text("Emergency Exit Focus Session") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "Leaving before completing the $targetMinutes-minute target will record an interrupted session and affect your daily focus score.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        OutlinedTextField(
                            value = emergencyExitReason,
                            onValueChange = { emergencyExitReason = it },
                            label = { Text("Reason for Exit") },
                            placeholder = { Text("e.g. Urgent call, library closed") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.interruptFocusSession(emergencyExitReason.ifBlank { "Unspecified early exit" })
                            emergencyExitReason = ""
                            showEmergencyExitDialog = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AlertRose)
                    ) {
                        Text("Confirm Interruption")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showEmergencyExitDialog = false }) {
                        Text("Stay Focused")
                    }
                }
            )
        }

        // Add Blocked App Dialog
        if (showAddBlockAppDialog) {
            AlertDialog(
                onDismissRequest = { showAddBlockAppDialog = false },
                title = { Text("Add App to Blocklist") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = newAppName,
                            onValueChange = { newAppName = it },
                            label = { Text("Application Name / Domain") },
                            placeholder = { Text("e.g. LinkedIn, Telegram") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (newAppName.isNotBlank()) {
                                coroutineScope.launch {
                                    viewModel.repository.addBlockedApp(newAppName, "com.custom.${newAppName.lowercase()}", newAppCategory)
                                    newAppName = ""
                                    showAddBlockAppDialog = false
                                }
                            }
                        }
                    ) {
                        Text("Add to Blocklist")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showAddBlockAppDialog = false }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}
