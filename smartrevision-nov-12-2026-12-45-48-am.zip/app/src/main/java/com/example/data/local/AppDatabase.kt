package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        UserProfile::class,
        Subject::class,
        Chapter::class,
        Topic::class,
        StudySession::class,
        RevisionSchedule::class,
        FocusSession::class,
        BlockedApp::class,
        StudyNote::class,
        McqSession::class,
        MockExam::class,
        VocabularyWord::class,
        ExamCountdown::class,
        AppNotification::class,
        PaymentTransaction::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userProfileDao(): UserProfileDao
    abstract fun subjectDao(): SubjectDao
    abstract fun chapterDao(): ChapterDao
    abstract fun topicDao(): TopicDao
    abstract fun studySessionDao(): StudySessionDao
    abstract fun revisionScheduleDao(): RevisionScheduleDao
    abstract fun focusSessionDao(): FocusSessionDao
    abstract fun blockedAppDao(): BlockedAppDao
    abstract fun studyNoteDao(): StudyNoteDao
    abstract fun mcqSessionDao(): McqSessionDao
    abstract fun mockExamDao(): MockExamDao
    abstract fun vocabularyDao(): VocabularyDao
    abstract fun examCountdownDao(): ExamCountdownDao
    abstract fun appNotificationDao(): AppNotificationDao
    abstract fun paymentTransactionDao(): PaymentTransactionDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "smart_revision_db"
                )
                    .addCallback(DatabaseCallback())
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback : Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    CoroutineScope(Dispatchers.IO).launch {
                        populateInitialData(database)
                    }
                }
            }
        }

        suspend fun populateInitialData(db: AppDatabase) {
            // 1. Initial User Profile
            db.userProfileDao().insertOrUpdate(
                UserProfile(
                    id = 1L,
                    name = "Saif Ahmed",
                    email = "saif.bcs47@aspirant.bd",
                    targetExam = "47th BCS & Bangladesh Bank AD",
                    dailyTargetMinutes = 360,
                    isPremium = true,
                    currentStreakDays = 14,
                    longestStreakDays = 24
                )
            )

            // 2. Pre-seeded Competitive Examination Subjects
            val subjects = listOf(
                Subject(1, "Bangladesh Affairs", "#EF4444", "Flag", true),
                Subject(2, "International Affairs", "#3B82F6", "Public", true),
                Subject(3, "English Grammar", "#8B5CF6", "MenuBook", true),
                Subject(4, "English Literature", "#EC4899", "AutoStories", true),
                Subject(5, "Mathematics", "#10B981", "Calculate", true),
                Subject(6, "Mental Ability", "#F59E0B", "Psychology", true),
                Subject(7, "General Science", "#06B6D4", "Science", true),
                Subject(8, "Geography & Environment", "#14B8A6", "Terrain", true),
                Subject(9, "Computer & ICT", "#6366F1", "Computer", true),
                Subject(10, "Bangladesh Constitution", "#D97706", "Gavel", true),
                Subject(11, "General Knowledge", "#84CC16", "Lightbulb", true)
            )
            db.subjectDao().insertSubjects(subjects)

            // 3. Pre-seeded Chapters & High-Yield Topics
            val chapters = listOf(
                Chapter(1, 1, "Liberation War of 1971 & Background", 1),
                Chapter(2, 1, "Ancient & Medieval Bengal History", 2),
                Chapter(3, 10, "Preamble & Fundamental Principles", 1),
                Chapter(4, 10, "Fundamental Rights & Constitutional Amendments", 2),
                Chapter(5, 3, "Parts of Speech & Advanced Clauses", 1),
                Chapter(6, 4, "Elizabethan & Romantic Periods", 1),
                Chapter(7, 5, "Percentage, Profit & Loss", 1),
                Chapter(8, 9, "Networking, Cloud & Cyber Security", 1)
            )
            db.chapterDao().insertChapters(chapters)

            val now = System.currentTimeMillis()
            val dayMillis = 86_400_000L

            val topics = listOf(
                Topic(1, 1, 1, "Six-Point Movement & 1969 Mass Uprising", Priority.HIGH, TopicStatus.COMPLETED, "Foundational political milestones leading to independence", true, 95, now - 5 * dayMillis, "Focus on student action committee 11 points"),
                Topic(2, 1, 1, "Declaration of Independence & Mujibnagar Government", Priority.HIGH, TopicStatus.COMPLETED, "Ministries, sector commanders and oath ceremony on April 17, 1971", false, 80, now - 3 * dayMillis, "Oath read by Prof Yusuf Ali"),
                Topic(3, 3, 10, "Fundamental Principles of State Policy (Articles 8-25)", Priority.HIGH, TopicStatus.IN_PROGRESS, "Four pillars: Nationalism, Socialism, Democracy, Secularism", false, 60, now - 1 * dayMillis, "Non-justiciable principles in court"),
                Topic(4, 4, 10, "Fundamental Rights (Articles 26-47A)", Priority.HIGH, TopicStatus.NOT_STARTED, "Key writs: Habeas Corpus, Mandamus, Quo Warranto, Certiorari", true, 0, null, ""),
                Topic(5, 5, 3, "Identification of Noun, Adjective & Adverb Clauses", Priority.MEDIUM, TopicStatus.COMPLETED, "Past BCS recurring question pattern", false, 75, now - 8 * dayMillis, "Who, which, that clause distinctions"),
                Topic(6, 6, 4, "Shakespearean Tragedies & Major Characters", Priority.HIGH, TopicStatus.IN_PROGRESS, "Hamlet, Othello, King Lear, Macbeth quotes and themes", false, 45, now, "Quotes like 'To be or not to be'"),
                Topic(7, 7, 5, "Compound Interest & Profit-Loss Formulas", Priority.HIGH, TopicStatus.COMPLETED, "Bank exam shortcut formulas", true, 110, now - 11 * dayMillis, "A = P(1 + r/n)^(nt)"),
                Topic(8, 8, 9, "IPv4 vs IPv6 & OSI 7-Layer Protocol Stack", Priority.MEDIUM, TopicStatus.NOT_STARTED, "Layer functions and protocols (TCP/UDP, HTTP, DNS)", false, 0, null, "")
            )
            db.topicDao().insertTopics(topics)

            // 4. Initial Smart 4-7-10 Spaced Repetition Revisions
            // Topic 1 was studied 5 days ago: 1st revision (after 4 days) was yesterday -> Overdue or ready today!
            val revisions = listOf(
                RevisionSchedule(
                    id = 1,
                    topicId = 1,
                    subjectId = 1,
                    topicName = "Six-Point Movement & 1969 Mass Uprising",
                    subjectName = "Bangladesh Affairs",
                    chapterName = "Liberation War of 1971 & Background",
                    intervalDays = 4,
                    intervalIndex = 1,
                    originalStudyDateMillis = now - 5 * dayMillis,
                    scheduledDateMillis = now, // Due Today!
                    mode = RevisionMode.MODE_A_FIXED,
                    isCompleted = false
                ),
                RevisionSchedule(
                    id = 2,
                    topicId = 2,
                    subjectId = 1,
                    topicName = "Declaration of Independence & Mujibnagar Government",
                    subjectName = "Bangladesh Affairs",
                    chapterName = "Liberation War of 1971 & Background",
                    intervalDays = 4,
                    intervalIndex = 1,
                    originalStudyDateMillis = now - 3 * dayMillis,
                    scheduledDateMillis = now + 1 * dayMillis, // Upcoming tomorrow
                    mode = RevisionMode.MODE_A_FIXED,
                    isCompleted = false
                ),
                RevisionSchedule(
                    id = 3,
                    topicId = 5,
                    subjectId = 3,
                    topicName = "Identification of Noun, Adjective & Adverb Clauses",
                    subjectName = "English Grammar",
                    chapterName = "Parts of Speech & Advanced Clauses",
                    intervalDays = 7,
                    intervalIndex = 2,
                    originalStudyDateMillis = now - 8 * dayMillis,
                    scheduledDateMillis = now - 1 * dayMillis, // Overdue
                    mode = RevisionMode.MODE_A_FIXED,
                    isCompleted = false
                ),
                RevisionSchedule(
                    id = 4,
                    topicId = 7,
                    subjectId = 5,
                    topicName = "Compound Interest & Profit-Loss Formulas",
                    subjectName = "Mathematics",
                    chapterName = "Percentage, Profit & Loss",
                    intervalDays = 4,
                    intervalIndex = 1,
                    originalStudyDateMillis = now - 11 * dayMillis,
                    scheduledDateMillis = now - 7 * dayMillis,
                    mode = RevisionMode.MODE_A_FIXED,
                    isCompleted = true,
                    completedDateMillis = now - 7 * dayMillis,
                    revisionNotes = "Formulas recalled well. Need more practice on quarterly compounding.",
                    rating = 4
                )
            )
            db.revisionScheduleDao().insertRevisions(revisions)

            // 5. Initial Study Sessions
            val studySessions = listOf(
                StudySession(1, 1, 1, 1, "Bangladesh Affairs", "Liberation War of 1971", "Six-Point Movement & 1969 Mass Uprising", 65, now - 4 * 3600_000L, now - 3 * 3600_000L, "Deep study of historical chronology", "Timer"),
                StudySession(2, 5, 7, 7, "Mathematics", "Percentage, Profit & Loss", "Compound Interest & Profit-Loss Formulas", 50, now - 2 * 3600_000L, now - 1 * 3600_000L, "Solved 25 previous year questions", "Pomodoro"),
                StudySession(3, 10, 3, 3, "Bangladesh Constitution", "Preamble & Fundamental Principles", "Fundamental Principles of State Policy", 45, now - 45 * 60_000L, now, "Articles 8 through 25 memorized", "Timer")
            )
            studySessions.forEach { db.studySessionDao().insertSession(it) }

            // 6. Blocked Apps for Strict Focus Mode
            val blockedApps = listOf(
                BlockedApp(1, "Facebook", "com.facebook.katana", "Social Media", true),
                BlockedApp(2, "YouTube", "com.google.android.youtube", "Video & Entertainment", true),
                BlockedApp(3, "Instagram", "com.instagram.android", "Social Media", true),
                BlockedApp(4, "TikTok", "com.zhiliaoapp.musically", "Social Media", true),
                BlockedApp(5, "X / Twitter", "com.twitter.android", "Social Media", true),
                BlockedApp(6, "Reddit", "com.reddit.frontpage", "Social Media", true),
                BlockedApp(7, "Netflix", "com.netflix.mediaclient", "Video & Entertainment", true),
                BlockedApp(8, "Snapchat", "com.snapchat.android", "Social Media", true)
            )
            db.blockedAppDao().insertApps(blockedApps)

            // 7. High-Yield Vocabulary
            val vocabulary = listOf(
                VocabularyWord(
                    id = 1,
                    word = "Abnegation",
                    bengaliMeaning = "আত্মত্যাগ বা নিজের স্বার্থ বিসর্জন",
                    definition = "The act of renouncing or rejecting something.",
                    synonyms = "Renunciation, surrender, self-denial",
                    antonyms = "Indulgence, acceptance, claim",
                    exampleSentence = "Her abnegation of luxurious pleasures inspired everyone in the team.",
                    masteryLevel = MasteryLevel.REVIEWING,
                    isFavorite = true
                ),
                VocabularyWord(
                    id = 2,
                    word = "Belligerent",
                    bengaliMeaning = "যুদ্ধংদেহী বা কলহপ্রিয়",
                    definition = "Hostile and aggressive; ready to fight.",
                    synonyms = "Combative, pugnacious, antagonistic",
                    antonyms = "Peaceable, amicable, friendly",
                    exampleSentence = "The candidate avoided a belligerent tone during the heated debate.",
                    masteryLevel = MasteryLevel.LEARNING,
                    isFavorite = false
                ),
                VocabularyWord(
                    id = 3,
                    word = "Capitulate",
                    bengaliMeaning = "শর্তাধীনে আত্মসমর্পণ করা",
                    definition = "Cease to resist an opponent; surrender.",
                    synonyms = "Surrender, yield, submit, concede",
                    antonyms = "Resist, conquer, defy",
                    exampleSentence = "The besieged garrison had no choice but to capitulate.",
                    masteryLevel = MasteryLevel.MASTERED,
                    isFavorite = true
                ),
                VocabularyWord(
                    id = 4,
                    word = "Ephemeral",
                    bengaliMeaning = "ক্ষণস্থায়ী বা স্বল্পস্থায়ী",
                    definition = "Lasting for a very short time.",
                    synonyms = "Transient, fleeting, momentary",
                    antonyms = "Permanent, enduring, eternal",
                    exampleSentence = "Fame in social media is often ephemeral.",
                    masteryLevel = MasteryLevel.REVIEWING,
                    isFavorite = true
                ),
                VocabularyWord(
                    id = 5,
                    word = "Meticulous",
                    bengaliMeaning = "খুঁতখুঁতে বা অতি সতর্ক",
                    definition = "Showing great attention to detail; very careful and precise.",
                    synonyms = "Conscientious, diligent, scrupulous",
                    antonyms = "Careless, sloppy, neglectful",
                    exampleSentence = "He kept meticulous notes for the BCS written examination.",
                    masteryLevel = MasteryLevel.MASTERED,
                    isFavorite = false
                )
            )
            db.vocabularyDao().insertWords(vocabulary)

            // 8. Real Competitive Exam Countdowns
            val examCountdowns = listOf(
                ExamCountdown(1, "47th BCS Preliminary", now + 68 * dayMillis, 450, 185f, "BCS"),
                ExamCountdown(2, "Bangladesh Bank Assistant Director (General)", now + 34 * dayMillis, 300, 140f, "Bank"),
                ExamCountdown(3, "46th BCS Written Examination", now + 112 * dayMillis, 600, 210f, "BCS"),
                ExamCountdown(4, "Combined 10 Banks Officer (Cash)", now + 52 * dayMillis, 250, 95f, "Bank")
            )
            examCountdowns.forEach { db.examCountdownDao().insertExam(it) }

            // 9. Study Notes
            val notes = listOf(
                StudyNote(
                    id = 1,
                    subjectId = 1,
                    topicId = 1,
                    subjectName = "Bangladesh Affairs",
                    topicName = "Six-Point Movement & 1969 Mass Uprising",
                    title = "Historic 6 Points of 1966 Breakdown",
                    content = "Point 1: Federal form of government based on Lahore resolution.\nPoint 2: Central govt handles only Defense and Foreign Affairs.\nPoint 3: Two separate but freely convertible currencies.\nPoint 4: Taxation power vested with federating units.\nPoint 5: Separate external trade accounts.\nPoint 6: Paramilitary force for East Pakistan.",
                    tags = "BCS, 1966, Six Points, High Yield",
                    isFavorite = true
                ),
                StudyNote(
                    id = 2,
                    subjectId = 10,
                    topicId = 3,
                    subjectName = "Bangladesh Constitution",
                    topicName = "Fundamental Principles of State Policy",
                    title = "Key Articles for Preliminary Exam",
                    content = "Article 9: Nationalism.\nArticle 10: Socialism and freedom from exploitation.\nArticle 11: Democracy and Human Rights.\nArticle 12: Secularism and freedom of religion.\nArticle 17: Free and compulsory education.\nArticle 18A: Protection and improvement of environment and biodiversity.",
                    tags = "Constitution, Articles, Short Notes",
                    isFavorite = true
                )
            )
            notes.forEach { db.studyNoteDao().insertNote(it) }

            // 10. Sample MCQ and Mock Exam Records
            db.mcqSessionDao().insertMcqSession(
                McqSession(1, 1, "Bangladesh Affairs", "Liberation War of 1971", 50, 44, 4, 2, 28, 88.0f, now - 2 * dayMillis)
            )
            db.mcqSessionDao().insertMcqSession(
                McqSession(2, 5, "Mathematics", "Percentage & Profit", 40, 32, 6, 2, 35, 80.0f, now - 1 * dayMillis)
            )
            db.mockExamDao().insertMockExam(
                MockExam(1, "BCS Full Preliminary Model Test #1", now - 6 * dayMillis, 200f, 138.5f, 152, 13.5f, 120, "Bangla: 28, English: 25, Math: 21, GK: 45", "Target scored above 135 cutoff! Need revision on English literature.")
            )

            // 11. Initial Notifications
            val notifications = listOf(
                AppNotification(1, "Revision Due Today!", "You have 1 topic scheduled for spaced repetition review today.", "REVISION_TODAY", now - 3600_000L, false, "revision"),
                AppNotification(2, "14-Day Study Streak Active!", "Incredible discipline! Keep going to reach your 28-day personal best.", "STREAK", now - 12 * 3600_000L, true, "dashboard"),
                AppNotification(3, "47th BCS Preliminary in 68 Days", "Check your daily progress target to complete 450 study hours.", "COUNTDOWN", now - 24 * 3600_000L, true, "countdown")
            )
            notifications.forEach { db.appNotificationDao().insertNotification(it) }
        }
    }
}
