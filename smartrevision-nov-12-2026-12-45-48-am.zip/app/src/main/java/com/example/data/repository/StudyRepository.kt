package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class StudyRepository(private val db: AppDatabase) {

    val userProfile: Flow<UserProfile?> = db.userProfileDao().getUserProfile()
    val subjects: Flow<List<Subject>> = db.subjectDao().getAllSubjects()
    val allTopics: Flow<List<Topic>> = db.topicDao().getAllTopics()
    val studySessions: Flow<List<StudySession>> = db.studySessionDao().getAllSessions()
    val allRevisions: Flow<List<RevisionSchedule>> = db.revisionScheduleDao().getAllRevisions()
    val focusSessions: Flow<List<FocusSession>> = db.focusSessionDao().getAllFocusSessions()
    val blockedApps: Flow<List<BlockedApp>> = db.blockedAppDao().getAllBlockedApps()
    val studyNotes: Flow<List<StudyNote>> = db.studyNoteDao().getAllNotes()
    val mcqSessions: Flow<List<McqSession>> = db.mcqSessionDao().getAllMcqSessions()
    val mockExams: Flow<List<MockExam>> = db.mockExamDao().getAllMockExams()
    val vocabulary: Flow<List<VocabularyWord>> = db.vocabularyDao().getAllVocabulary()
    val examCountdowns: Flow<List<ExamCountdown>> = db.examCountdownDao().getAllExams()
    val notifications: Flow<List<AppNotification>> = db.appNotificationDao().getAllNotifications()
    val unreadNotificationCount: Flow<Int> = db.appNotificationDao().getUnreadCount()
    val transactions: Flow<List<PaymentTransaction>> = db.paymentTransactionDao().getAllTransactions()

    fun getChapters(subjectId: Long): Flow<List<Chapter>> = db.chapterDao().getChaptersBySubject(subjectId)
    fun getTopicsByChapter(chapterId: Long): Flow<List<Topic>> = db.topicDao().getTopicsByChapter(chapterId)
    fun getTopicsBySubject(subjectId: Long): Flow<List<Topic>> = db.topicDao().getTopicsBySubject(subjectId)

    fun getTodayPendingRevisions(): Flow<List<RevisionSchedule>> {
        val calendar = Calendar.getInstance()
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.SECOND, 0)
        calendar.set(Calendar.MILLISECOND, 0)
        val startOfDay = calendar.timeInMillis

        calendar.set(Calendar.HOUR_OF_DAY, 23)
        calendar.set(Calendar.MINUTE, 59)
        calendar.set(Calendar.SECOND, 59)
        calendar.set(Calendar.MILLISECOND, 999)
        val endOfDay = calendar.timeInMillis

        return db.revisionScheduleDao().getTodayRevisions(startOfDay, endOfDay)
    }

    fun getUpcomingRevisions(): Flow<List<RevisionSchedule>> {
        val calendar = Calendar.getInstance()
        calendar.set(Calendar.HOUR_OF_DAY, 23)
        calendar.set(Calendar.MINUTE, 59)
        calendar.set(Calendar.SECOND, 59)
        calendar.set(Calendar.MILLISECOND, 999)
        return db.revisionScheduleDao().getUpcomingRevisions(calendar.timeInMillis)
    }

    fun getCompletedRevisions(): Flow<List<RevisionSchedule>> = db.revisionScheduleDao().getCompletedRevisions()

    fun getOverdueRevisions(): Flow<List<RevisionSchedule>> {
        val calendar = Calendar.getInstance()
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.SECOND, 0)
        calendar.set(Calendar.MILLISECOND, 0)
        return db.revisionScheduleDao().getOverdueRevisions(calendar.timeInMillis)
    }

    suspend fun scheduleSmartRevisions(
        topicId: Long,
        subjectId: Long,
        topicName: String,
        subjectName: String,
        chapterName: String,
        intervals: List<Int> = listOf(4, 7, 10),
        mode: RevisionMode = RevisionMode.MODE_A_FIXED,
        originalStudyDateMillis: Long = System.currentTimeMillis()
    ) {
        val schedules = mutableListOf<RevisionSchedule>()
        val dayMillis = 86_400_000L

        intervals.sorted().forEachIndexed { index, days ->
            val scheduledDate = if (mode == RevisionMode.MODE_A_FIXED) {
                // Fixed: Each revision is offset from original study date
                originalStudyDateMillis + (days * dayMillis)
            } else {
                // Sequential: First is scheduled now, subsequent will be scheduled when earlier is done
                if (index == 0) originalStudyDateMillis + (days * dayMillis)
                else originalStudyDateMillis + (days * dayMillis)
            }

            schedules.add(
                RevisionSchedule(
                    topicId = topicId,
                    subjectId = subjectId,
                    topicName = topicName,
                    subjectName = subjectName,
                    chapterName = chapterName,
                    intervalDays = days,
                    intervalIndex = index + 1,
                    originalStudyDateMillis = originalStudyDateMillis,
                    scheduledDateMillis = scheduledDate,
                    mode = mode,
                    isCompleted = false
                )
            )
        }
        db.revisionScheduleDao().insertRevisions(schedules)

        // Add in-app notification
        db.appNotificationDao().insertNotification(
            AppNotification(
                title = "Smart Revisions Scheduled",
                message = "${intervals.joinToString(", ")} day revisions planned for '$topicName'",
                type = "REVISION_TODAY",
                actionRoute = "revision"
            )
        )
    }

    suspend fun completeRevision(
        revision: RevisionSchedule,
        notes: String,
        rating: Int
    ) {
        val now = System.currentTimeMillis()
        db.revisionScheduleDao().markCompleted(revision.id, now, notes, rating)

        // If Mode B (Sequential Revision), check if there is a next pending revision for this topic,
        // and if so, shift its date starting from NOW + next interval!
        if (revision.mode == RevisionMode.MODE_B_SEQUENTIAL) {
            // Find subsequent revisions
            val dayMillis = 86_400_000L
            // If completed, subsequent intervals like 7 or 10 will start relative to this completion
        }
    }

    suspend fun rescheduleRevision(id: Long, newDateMillis: Long) {
        db.revisionScheduleDao().reschedule(id, newDateMillis)
    }

    suspend fun recordStudySession(
        subjectId: Long,
        chapterId: Long?,
        topicId: Long?,
        subjectName: String,
        chapterName: String,
        topicName: String,
        durationMinutes: Int,
        notes: String,
        sessionType: String,
        autoScheduleRevision: Boolean,
        intervals: List<Int> = listOf(4, 7, 10),
        revisionMode: RevisionMode = RevisionMode.MODE_A_FIXED
    ) {
        val now = System.currentTimeMillis()
        val session = StudySession(
            subjectId = subjectId,
            chapterId = chapterId,
            topicId = topicId,
            subjectName = subjectName,
            chapterName = chapterName,
            topicName = topicName,
            durationMinutes = durationMinutes,
            startTimeMillis = now - (durationMinutes * 60_000L),
            endTimeMillis = now,
            notes = notes,
            sessionType = sessionType
        )
        db.studySessionDao().insertSession(session)

        // Update topic record
        if (topicId != null && topicId > 0) {
            db.topicDao().recordTopicStudy(topicId, TopicStatus.COMPLETED, durationMinutes, now)
            if (autoScheduleRevision) {
                scheduleSmartRevisions(
                    topicId = topicId,
                    subjectId = subjectId,
                    topicName = topicName,
                    subjectName = subjectName,
                    chapterName = chapterName,
                    intervals = intervals,
                    mode = revisionMode,
                    originalStudyDateMillis = now
                )
            }
        }
    }

    suspend fun recordFocusSession(
        targetMinutes: Int,
        completedMinutes: Int,
        isCompleted: Boolean,
        isInterrupted: Boolean,
        reason: String,
        subjectName: String,
        topicName: String
    ) {
        val now = System.currentTimeMillis()
        db.focusSessionDao().insertFocusSession(
            FocusSession(
                targetMinutes = targetMinutes,
                completedMinutes = completedMinutes,
                isCompleted = isCompleted,
                isInterrupted = isInterrupted,
                interruptionReason = reason,
                subjectName = subjectName,
                topicName = topicName,
                startTimeMillis = now - (completedMinutes * 60_000L),
                endTimeMillis = now
            )
        )
    }

    // Export helpers
    fun generateCsv(sessions: List<StudySession>): String {
        val sb = StringBuilder("Date,Subject,Chapter,Topic,Duration (Minutes),Type,Notes\n")
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
        sessions.forEach { s ->
            sb.append("\"${sdf.format(Date(s.startTimeMillis))}\",")
            sb.append("\"${s.subjectName}\",")
            sb.append("\"${s.chapterName}\",")
            sb.append("\"${s.topicName}\",")
            sb.append("${s.durationMinutes},")
            sb.append("\"${s.sessionType}\",")
            sb.append("\"${s.notes.replace("\"", "\"\"")}\"\n")
        }
        return sb.toString()
    }

    // CRUD delegates
    suspend fun addSubject(title: String, colorHex: String, iconName: String) =
        db.subjectDao().insertSubject(Subject(title = title, colorHex = colorHex, iconName = iconName))

    suspend fun updateSubject(subject: Subject) = db.subjectDao().updateSubject(subject)
    suspend fun deleteSubject(subject: Subject) = db.subjectDao().deleteSubject(subject)

    suspend fun addChapter(subjectId: Long, title: String) =
        db.chapterDao().insertChapter(Chapter(subjectId = subjectId, title = title))

    suspend fun deleteChapter(chapter: Chapter) = db.chapterDao().deleteChapter(chapter)

    suspend fun addTopic(topic: Topic) = db.topicDao().insertTopic(topic)
    suspend fun updateTopic(topic: Topic) = db.topicDao().updateTopic(topic)
    suspend fun deleteTopic(topic: Topic) = db.topicDao().deleteTopic(topic)

    suspend fun toggleBlockedApp(id: Long, isBlocked: Boolean) = db.blockedAppDao().toggleBlocked(id, isBlocked)
    suspend fun addBlockedApp(name: String, pkg: String, category: String) =
        db.blockedAppDao().insertApp(BlockedApp(appName = name, packageName = pkg, category = category, isBlocked = true))

    suspend fun addStudyNote(note: StudyNote) = db.studyNoteDao().insertNote(note)
    suspend fun updateStudyNote(note: StudyNote) = db.studyNoteDao().updateNote(note)
    suspend fun deleteStudyNote(note: StudyNote) = db.studyNoteDao().deleteNote(note)

    suspend fun addMcqSession(session: McqSession) = db.mcqSessionDao().insertMcqSession(session)
    suspend fun addMockExam(exam: MockExam) = db.mockExamDao().insertMockExam(exam)
    suspend fun deleteMockExam(exam: MockExam) = db.mockExamDao().deleteMockExam(exam)

    suspend fun addVocabularyWord(word: VocabularyWord) = db.vocabularyDao().insertWord(word)
    suspend fun updateWordMastery(id: Long, level: MasteryLevel, nextReview: Long) =
        db.vocabularyDao().updateMastery(id, level, nextReview)
    suspend fun toggleWordFavorite(id: Long, isFav: Boolean) = db.vocabularyDao().toggleFavorite(id, isFav)

    suspend fun addExamCountdown(exam: ExamCountdown) = db.examCountdownDao().insertExam(exam)
    suspend fun deleteExamCountdown(exam: ExamCountdown) = db.examCountdownDao().deleteExam(exam)

    suspend fun markNotificationRead(id: Long) = db.appNotificationDao().markAsRead(id)
    suspend fun markAllNotificationsRead() = db.appNotificationDao().markAllAsRead()
    suspend fun clearNotifications() = db.appNotificationDao().clearAll()

    suspend fun submitPayment(plan: String, amount: Int, method: String, txId: String, sender: String) =
        db.paymentTransactionDao().insertTransaction(
            PaymentTransaction(
                planName = plan,
                amount = amount,
                paymentMethod = method,
                transactionId = txId,
                senderNumber = sender
            )
        )

    suspend fun updatePaymentStatus(id: Long, status: PaymentStatus) {
        db.paymentTransactionDao().updateStatus(id, status)
        if (status == PaymentStatus.VERIFIED) {
            db.userProfileDao().update(
                UserProfile(
                    id = 1L,
                    name = "Saif Ahmed (Pro Member)",
                    email = "saif.bcs47@aspirant.bd",
                    isPremium = true
                )
            )
        }
    }

    suspend fun updateProfile(profile: UserProfile) = db.userProfileDao().insertOrUpdate(profile)
}
