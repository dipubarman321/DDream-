package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.components.AppHeader
import com.example.ui.components.PriorityBadge
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubjectsScreen(
    viewModel: MainViewModel,
    onMenuClick: () -> Unit
) {
    val subjects by viewModel.subjects.collectAsState()
    val allTopics by viewModel.allTopics.collectAsState()
    val unreadNotifications by viewModel.unreadNotificationsCount.collectAsState()
    val coroutineScope = rememberCoroutineScope()

    var selectedSubjectId by remember { mutableStateOf<Long?>(null) }
    var showAddSubjectDialog by remember { mutableStateOf(false) }
    var showAddTopicDialog by remember { mutableStateOf(false) }
    var newSubjectTitle by remember { mutableStateOf("") }
    var newSubjectColor by remember { mutableStateOf("#4F46E5") }

    var topicTitle by remember { mutableStateOf("") }
    var topicDescription by remember { mutableStateOf("") }
    var topicPriority by remember { mutableStateOf(Priority.HIGH) }
    var topicIsDifficult by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            AppHeader(
                title = "Subjects & Syllabus",
                subtitle = "${subjects.size} Competitive Exam Subjects",
                onMenuClick = onMenuClick,
                unreadNotifications = unreadNotifications,
                onNotificationsClick = { viewModel.navigateTo("notifications") }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    if (selectedSubjectId != null) showAddTopicDialog = true
                    else showAddSubjectDialog = true
                },
                containerColor = BrandIndigo600,
                contentColor = Color.White,
                modifier = Modifier.testTag("subjects_fab_add")
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = if (selectedSubjectId != null) "Add Topic" else "Add Subject"
                )
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 90.dp)
        ) {
            item {
                Text(
                    text = "BCS & Bank Exam Syllabus",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "Tap any subject to view topics, track status, or schedule 4-7-10 day revisions.",
                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                )
            }

            items(subjects, key = { it.id }) { subject ->
                val isExpanded = selectedSubjectId == subject.id
                val subjectTopics = allTopics.filter { it.subjectId == subject.id }
                val completedCount = subjectTopics.count { it.status == TopicStatus.COMPLETED }
                val totalCount = subjectTopics.size
                val completionPercent = if (totalCount > 0) (completedCount * 100 / totalCount) else 0

                val color = try {
                    Color(android.graphics.Color.parseColor(subject.colorHex))
                } catch (e: Exception) {
                    BrandIndigo600
                }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .clickable {
                            selectedSubjectId = if (isExpanded) null else subject.id
                        }
                        .testTag("subject_card_${subject.id}"),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isExpanded) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f) else MaterialTheme.colorScheme.surface
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .background(color.copy(alpha = 0.15f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Book,
                                    contentDescription = null,
                                    tint = color,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = subject.title,
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "$completedCount/$totalCount topics completed ($completionPercent%)",
                                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                )
                            }
                            Icon(
                                imageVector = if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                contentDescription = "Expand",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        // Linear progress indicator for topic completion
                        Spacer(modifier = Modifier.height(10.dp))
                        LinearProgressIndicator(
                            progress = { if (totalCount > 0) completedCount.toFloat() / totalCount else 0f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = color,
                            trackColor = Slate200
                        )

                        // Expanded Topics list
                        AnimatedVisibility(visible = isExpanded) {
                            Column(modifier = Modifier.padding(top = 16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Topics in this Subject",
                                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                                    )
                                    TextButton(onClick = { showAddTopicDialog = true }) {
                                        Text("+ Add Topic", color = BrandIndigo600, fontSize = 13.sp)
                                    }
                                }

                                if (subjectTopics.isEmpty()) {
                                    Text(
                                        text = "No topics added yet. Tap '+ Add Topic' to build your syllabus.",
                                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant),
                                        modifier = Modifier.padding(vertical = 8.dp)
                                    )
                                } else {
                                    subjectTopics.forEach { topic ->
                                        Surface(
                                            color = MaterialTheme.colorScheme.surface,
                                            shape = RoundedCornerShape(12.dp),
                                            tonalElevation = 1.dp,
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(vertical = 4.dp)
                                        ) {
                                            Column(modifier = Modifier.padding(12.dp)) {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.SpaceBetween
                                                ) {
                                                    Column(modifier = Modifier.weight(1f)) {
                                                        Text(
                                                            text = topic.title,
                                                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                                                        )
                                                        if (topic.description.isNotBlank()) {
                                                            Text(
                                                                text = topic.description,
                                                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant),
                                                                maxLines = 2,
                                                                overflow = TextOverflow.Ellipsis
                                                            )
                                                        }
                                                    }
                                                    StatusBadge(status = topic.status)
                                                }

                                                Spacer(modifier = Modifier.height(8.dp))

                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.SpaceBetween
                                                ) {
                                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                        PriorityBadge(priority = topic.priority)
                                                        if (topic.isDifficult) {
                                                            Surface(
                                                                color = AlertRose.copy(alpha = 0.12f),
                                                                shape = RoundedCornerShape(6.dp)
                                                            ) {
                                                                Text(
                                                                    text = "Difficult",
                                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                                                    style = MaterialTheme.typography.labelSmall.copy(
                                                                        color = AlertRose,
                                                                        fontWeight = FontWeight.Bold
                                                                    )
                                                                )
                                                            }
                                                        }
                                                        if (topic.timeSpentMinutes > 0) {
                                                            Text(
                                                                text = "• ${topic.timeSpentMinutes}m spent",
                                                                style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant),
                                                                modifier = Modifier.align(Alignment.CenterVertically)
                                                            )
                                                        }
                                                    }

                                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                        // Toggle status button
                                                        OutlinedButton(
                                                            onClick = {
                                                                val nextStatus = when (topic.status) {
                                                                    TopicStatus.NOT_STARTED -> TopicStatus.IN_PROGRESS
                                                                    TopicStatus.IN_PROGRESS -> TopicStatus.COMPLETED
                                                                    TopicStatus.COMPLETED -> TopicStatus.NOT_STARTED
                                                                }
                                                                coroutineScope.launch {
                                                                    viewModel.repository.updateTopic(topic.copy(status = nextStatus))
                                                                }
                                                            },
                                                            modifier = Modifier.height(32.dp),
                                                            contentPadding = PaddingValues(horizontal = 8.dp),
                                                            shape = RoundedCornerShape(8.dp)
                                                        ) {
                                                            Text(
                                                                text = if (topic.status == TopicStatus.COMPLETED) "Completed ✓" else "Toggle",
                                                                fontSize = 11.sp
                                                            )
                                                        }

                                                        // Schedule 4-7-10 Revisions
                                                        Button(
                                                            onClick = {
                                                                coroutineScope.launch {
                                                                    viewModel.repository.scheduleSmartRevisions(
                                                                        topicId = topic.id,
                                                                        subjectId = subject.id,
                                                                        topicName = topic.title,
                                                                        subjectName = subject.title,
                                                                        chapterName = "",
                                                                        intervals = listOf(4, 7, 10),
                                                                        mode = RevisionMode.MODE_A_FIXED
                                                                    )
                                                                    viewModel.navigateTo("revision")
                                                                }
                                                            },
                                                            modifier = Modifier.height(32.dp),
                                                            colors = ButtonDefaults.buttonColors(containerColor = BrandIndigo600),
                                                            contentPadding = PaddingValues(horizontal = 8.dp),
                                                            shape = RoundedCornerShape(8.dp)
                                                        ) {
                                                            Text("4-7-10 Rev", fontSize = 11.sp)
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Add Subject Dialog
        if (showAddSubjectDialog) {
            AlertDialog(
                onDismissRequest = { showAddSubjectDialog = false },
                title = { Text("Add Custom Subject") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = newSubjectTitle,
                            onValueChange = { newSubjectTitle = it },
                            label = { Text("Subject Name") },
                            placeholder = { Text("e.g. Bangladesh Economic Trends") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text("Select Theme Color:", style = MaterialTheme.typography.bodySmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("#4F46E5", "#10B981", "#EF4444", "#F59E0B", "#8B5CF6", "#06B6D4").forEach { hex ->
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .background(Color(android.graphics.Color.parseColor(hex)), CircleShape)
                                        .border(
                                            width = if (newSubjectColor == hex) 3.dp else 0.dp,
                                            color = if (newSubjectColor == hex) Slate900 else Color.Transparent,
                                            shape = CircleShape
                                        )
                                        .clickable { newSubjectColor = hex }
                                )
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (newSubjectTitle.isNotBlank()) {
                                coroutineScope.launch {
                                    viewModel.repository.addSubject(newSubjectTitle, newSubjectColor, "Book")
                                    newSubjectTitle = ""
                                    showAddSubjectDialog = false
                                }
                            }
                        }
                    ) {
                        Text("Add Subject")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showAddSubjectDialog = false }) {
                        Text("Cancel")
                    }
                }
            )
        }

        // Add Topic Dialog
        if (showAddTopicDialog && selectedSubjectId != null) {
            val parentSubject = subjects.firstOrNull { it.id == selectedSubjectId }
            AlertDialog(
                onDismissRequest = { showAddTopicDialog = false },
                title = { Text("Add Topic to ${parentSubject?.title ?: ""}") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = topicTitle,
                            onValueChange = { topicTitle = it },
                            label = { Text("Topic Title") },
                            placeholder = { Text("e.g. Fundamental Rights Articles") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = topicDescription,
                            onValueChange = { topicDescription = it },
                            label = { Text("Topic Notes & Key Points") },
                            maxLines = 3,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Mark as Difficult Topic", style = MaterialTheme.typography.bodyMedium)
                            Switch(
                                checked = topicIsDifficult,
                                onCheckedChange = { topicIsDifficult = it }
                            )
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (topicTitle.isNotBlank()) {
                                coroutineScope.launch {
                                    viewModel.repository.addTopic(
                                        Topic(
                                            chapterId = 1L,
                                            subjectId = selectedSubjectId!!,
                                            title = topicTitle,
                                            priority = topicPriority,
                                            status = TopicStatus.NOT_STARTED,
                                            description = topicDescription,
                                            isDifficult = topicIsDifficult
                                        )
                                    )
                                    topicTitle = ""
                                    topicDescription = ""
                                    topicIsDifficult = false
                                    showAddTopicDialog = false
                                }
                            }
                        }
                    ) {
                        Text("Add Topic")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showAddTopicDialog = false }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}
